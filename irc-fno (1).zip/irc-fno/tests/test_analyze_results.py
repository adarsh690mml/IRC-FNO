import json
import os
import subprocess
import sys

import pandas as pd
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import analyze_results as AR


def _run(out, extra=()):
    cmd = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_irc.py"),
        "--smoke",
        "--cpu",
        "--out",
        out,
        "--components",
        "fp_12",
    ] + list(extra)
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]


def test_stage_waterfall_matches_history_and_manifest(tmp_path):
    out = str(tmp_path / "run")
    _run(out)
    cdirs = AR.find_component_dirs(out)
    assert cdirs == [("fp_12_seed0", os.path.join(out, "fp_12_seed0"))]
    rows, rep = AR.stage_waterfall(cdirs[0][1])
    hist = pd.read_csv(os.path.join(cdirs[0][1], "history.csv"))
    with open(os.path.join(cdirs[0][1], "test_report.json")) as f:
        rep2 = json.load(f)
    assert rows[0]["test_R2"] == pytest.approx(hist[hist["stage"] == "base"].iloc[0]["test_R2"])
    assert rows[-1]["test_R2"] == pytest.approx(rep2["test_final"]["R2"])
    assert rows[-1]["params_cumulative"] == rep2["accounting"]["params_total_effective"]
    assert rows[-1]["inference_flops_cumulative"] == pytest.approx(
        rep2["accounting"]["inference_flops_per_sample"]
    )


def test_run_stage_waterfalls_writes_summaries(tmp_path):
    out = str(tmp_path / "run")
    _run(out)
    AR.run_stage_waterfalls(out, out)
    assert os.path.exists(os.path.join(out, "contribution_summary.csv"))
    assert os.path.exists(os.path.join(out, "base_vs_final_summary.csv"))
    assert os.path.exists(os.path.join(out, "fp_12_seed0", "contribution.csv"))


def test_ablation_comparison_computes_correct_delta(tmp_path):
    base = str(tmp_path / "base")
    abl = str(tmp_path / "abl")
    _run(base)
    _run(abl, extra=["--set", "crossfit_folds=0"])
    out = str(tmp_path / "report")
    os.makedirs(out)
    AR.ablation_comparison(base, {"E3": abl}, out)
    df = pd.read_csv(os.path.join(out, "ablation_summary.csv"))
    assert len(df) == 1
    with open(os.path.join(base, "fp_12_seed0", "test_report.json")) as f:
        base_r2 = json.load(f)["test_final"]["R2"]
    with open(os.path.join(abl, "fp_12_seed0", "test_report.json")) as f:
        abl_r2 = json.load(f)["test_final"]["R2"]
    assert df.iloc[0]["delta_R2_vs_baseline"] == pytest.approx(abl_r2 - base_r2, abs=1e-09)
