import json
import os
import subprocess
import sys

import numpy as np
import pytest
import torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from irc import irno as Irno


def test_progressive_spectral_loss_zero_when_fields_equal():
    h = torch.randn(3, 1, 12, 14)
    assert Irno.progressive_spectral_loss(h, h, k=1, K=4).item() == pytest.approx(0.0, abs=1e-06)
    assert Irno.progressive_spectral_loss(h, h, k=4, K=4).item() == pytest.approx(0.0, abs=1e-06)


def test_progressive_spectral_loss_positive_when_fields_differ():
    h = torch.randn(3, 1, 12, 14)
    y = torch.randn(3, 1, 12, 14)
    assert Irno.progressive_spectral_loss(h, y, k=1, K=4).item() > 0


def test_unet_refiner_preserves_spatial_shape_odd_and_even():
    for H, W in [(16, 16), (15, 17), (10, 10)]:
        phi = Irno.UNetRefiner(in_channels=1, width=4, depth=2)
        x = torch.randn(2, 1, H, W)
        h = torch.randn(2, 1, H, W)
        out = phi(x, h)
        assert out.shape == (2, 1, H, W)


def test_rollout_K_steps_matches_manual_iteration():
    torch.manual_seed(0)
    phi = Irno.UNetRefiner(in_channels=1, width=4, depth=1)
    x = torch.randn(2, 1, 8, 8)
    h0 = torch.randn(2, 1, 8, 8)
    alpha = 0.3
    with torch.no_grad():
        h_manual = h0
        for _ in range(3):
            h_manual = h_manual + alpha * phi(x, h_manual)
        h_auto = Irno.rollout(phi, x, h0, K=3, alpha=alpha)
    assert torch.allclose(h_manual, h_auto, atol=1e-06)


def test_rollout_collect_returns_trajectory_of_right_length():
    phi = Irno.UNetRefiner(in_channels=1, width=4, depth=1)
    x = torch.randn(2, 1, 8, 8)
    h0 = torch.randn(2, 1, 8, 8)
    y = torch.randn(2, 1, 8, 8)
    hK, traj = Irno.rollout(phi, x, h0, K=4, alpha=0.5, y=y, collect=True)
    assert len(traj) == 4
    assert torch.allclose(traj[-1], hK)


def test_train_irno_runs_and_reduces_or_reports_loss(tmp_path):
    torch.manual_seed(0)
    n, H, W = (12, 10, 10)
    x = torch.rand(n, 1, H, W)
    y = torch.randn(n, 1, H, W) * 0.1
    h0 = torch.zeros(n, 1, H, W)
    phi = Irno.UNetRefiner(in_channels=1, width=4, depth=1)
    cfg = dict(
        irno_K=2,
        irno_alpha=0.5,
        irno_lr=0.001,
        irno_wd=0.0,
        irno_batch_size=4,
        irno_epochs=2,
        irno_beta_spectral=0.1,
        irno_beta_fp=0.1,
        seed=0,
        irno_log_every=1,
    )
    phi, hist, info = Irno.train_irno(
        phi, x[:8], y[:8], h0[:8], x[8:], y[8:], h0[8:], cfg, torch.device("cpu")
    )
    assert len(hist["epoch"]) == 2
    assert all(np.isfinite(hist["train_loss"]))
    assert info["best_val_mse"] >= 0


def test_run_irno_end_to_end_against_run_irc_base(tmp_path):
    base_out = str(tmp_path / "irc_base")
    irno_out = str(tmp_path / "irno")
    cmd_irc = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_irc.py"),
        "--smoke",
        "--cpu",
        "--out",
        base_out,
        "--components",
        "fp_12",
        "--mode",
        "base",
    ]
    r1 = subprocess.run(cmd_irc, capture_output=True, text=True, timeout=300)
    assert r1.returncode == 0, r1.stdout[-2000:] + r1.stderr[-2000:]
    cmd_irno = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_irno.py"),
        "--smoke",
        "--cpu",
        "--out",
        irno_out,
        "--irc-run-dir",
        base_out,
        "--component",
        "fp_12",
        "--K",
        "2",
        "--eval-K",
        "2",
        "4",
        "--epochs",
        "2",
    ]
    r2 = subprocess.run(cmd_irno, capture_output=True, text=True, timeout=300)
    assert r2.returncode == 0, r2.stdout[-3000:] + r2.stderr[-3000:]
    rep_path = os.path.join(irno_out, "test_report.json")
    assert os.path.exists(rep_path)
    rep = json.load(open(rep_path))
    assert rep["method"].startswith("IRNO")
    assert rep["K"] == 2
    assert "R2" in rep["test_final"] and "R2" in rep["test_base"]
    assert set(rep["extrapolation_R2_by_K"]) == {"2", "4"}
    assert os.path.exists(os.path.join(irno_out, "history.csv"))
    assert os.path.exists(os.path.join(irno_out, "irno_refiner.pt"))


def test_run_irno_refuses_nonempty_out(tmp_path):
    base_out = str(tmp_path / "irc_base")
    irno_out = str(tmp_path / "irno")
    subprocess.run(
        [
            sys.executable,
            os.path.join(ROOT, "scripts", "run_irc.py"),
            "--smoke",
            "--cpu",
            "--out",
            base_out,
            "--components",
            "fp_12",
            "--mode",
            "base",
        ],
        capture_output=True,
        text=True,
        timeout=300,
        check=True,
    )
    cmd = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_irno.py"),
        "--smoke",
        "--cpu",
        "--out",
        irno_out,
        "--irc-run-dir",
        base_out,
        "--component",
        "fp_12",
        "--epochs",
        "2",
    ]
    r1 = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    assert r1.returncode == 0
    r2 = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    assert r2.returncode != 0


def test_refiner_flops_matches_hand_count_single_conv():
    phi = Irno.UNetRefiner(in_channels=1, width=4, depth=1)
    f = Irno.refiner_flops(phi, 8, 8)
    c = lambda cin, cout, k, h, w: 2 * cin * k * k * cout * h * w
    expect = (
        c(2, 4, 3, 8, 8)
        + c(4, 4, 3, 8, 8)
        + c(4, 8, 3, 4, 4)
        + c(8, 8, 3, 4, 4)
        + c(12, 4, 3, 8, 8)
        + c(4, 4, 3, 8, 8)
        + c(4, 1, 1, 8, 8)
    )
    assert f == expect


def test_compare_irno_writes_comparison(tmp_path):
    base_out, irno_out = (str(tmp_path / "b"), str(tmp_path / "i"))
    subprocess.run(
        [
            sys.executable,
            os.path.join(ROOT, "scripts", "run_irc.py"),
            "--smoke",
            "--cpu",
            "--out",
            base_out,
            "--components",
            "fp_12",
            "--mode",
            "base",
        ],
        capture_output=True,
        text=True,
        timeout=300,
        check=True,
    )
    subprocess.run(
        [
            sys.executable,
            os.path.join(ROOT, "scripts", "run_irno.py"),
            "--smoke",
            "--cpu",
            "--out",
            irno_out,
            "--irc-run-dir",
            base_out,
            "--component",
            "fp_12",
            "--K",
            "2",
            "--epochs",
            "2",
        ],
        capture_output=True,
        text=True,
        timeout=300,
        check=True,
    )
    r = subprocess.run(
        [
            sys.executable,
            os.path.join(ROOT, "scripts", "compare_irno.py"),
            "--irc-run-dir",
            base_out,
            "--component",
            "fp_12",
            "--irno-run-dir",
            irno_out,
        ],
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0, r.stderr[-2000:]
    d = json.load(open(os.path.join(irno_out, "comparison.json")))
    irno_rep = json.load(open(os.path.join(irno_out, "test_report.json")))
    acct = irno_rep["accounting"]
    assert (
        acct["inference_flops_per_sample"]
        == acct["inference_flops_base"] + 2 * acct["inference_flops_refiner_per_step"]
    )
    assert d["irc_vs_irno"]["final_R2"]["irno"] == pytest.approx(irno_rep["test_final"]["R2"])


def test_run_irno_plasticity_root_layout(tmp_path):
    from test_irc_v2 import _write_plasticity_dataset

    root = str(tmp_path / "PLASTICITY DATA")
    morphs = ["Bicontinuous", "Elongated", "Inclusion", "Random"]
    _write_plasticity_dataset(root, "Isotropic", morphs, n_per_morph=8)
    _write_plasticity_dataset(root, "Linear", morphs, n_per_morph=8, seed=1)
    irc_out = str(tmp_path / "irc")
    fast = [
        "epochs=2",
        "batch_size=4",
        "modes1=4",
        "modes2=4",
        "width=8",
        "n_layers=2",
        "T_0=2",
        "log_every=1",
        "early_stop_patience=None",
        "mc_samples=0",
    ]
    subprocess.run(
        [
            sys.executable,
            os.path.join(ROOT, "scripts", "run_irc.py"),
            "--cpu",
            "--out",
            irc_out,
            "--plasticity-root",
            root,
            "--material-models",
            "Isotropic",
            "--components",
            "fp_12",
            "--mode",
            "base",
            "--set",
        ]
        + fast,
        capture_output=True,
        text=True,
        timeout=300,
        check=True,
    )
    irno_out = str(tmp_path / "irno")
    base = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_irno.py"),
        "--cpu",
        "--plasticity-root",
        root,
        "--component",
        "fp_12",
        "--irc-run-dir",
        os.path.join(irc_out, "Isotropic"),
        "--K",
        "2",
        "--epochs",
        "2",
    ]
    r = subprocess.run(
        base + ["--material-models", "Isotropic", "--out", irno_out],
        capture_output=True,
        text=True,
        timeout=300,
    )
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    assert os.path.exists(os.path.join(irno_out, "test_report.json"))
    r2 = subprocess.run(
        base + ["--material-models", "Isotropic", "Linear", "--out", str(tmp_path / "irno2")],
        capture_output=True,
        text=True,
        timeout=300,
    )
    assert r2.returncode != 0
