import os
import sys

import numpy as np
import pytest
import torch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from irc import physics as Ph


@pytest.fixture
def rng():
    return np.random.default_rng(3)


def test_alpha13_matches_manual_periodic_difference(rng):
    Fp12 = rng.standard_normal((6, 10, 12)).astype(np.float32)
    Fp11 = rng.standard_normal((6, 10, 12)).astype(np.float32)
    got = Ph.alpha13_np(Fp12, Fp11)
    manual = (np.roll(Fp12, -1, axis=-2) - np.roll(Fp12, 1, axis=-2)) / 2.0 - (
        np.roll(Fp11, -1, axis=-1) - np.roll(Fp11, 1, axis=-1)
    ) / 2.0
    np.testing.assert_allclose(got, manual, atol=1e-06)


def test_gnd_field_dispatch_is_symmetric_in_which_component_is_own(rng):
    Fp12 = rng.standard_normal((4, 8, 8)).astype(np.float32)
    Fp11 = rng.standard_normal((4, 8, 8)).astype(np.float32)
    a = Ph.gnd_field_np("fp_12", Fp12, Fp11)
    b = Ph.gnd_field_np("fp_11", Fp11, Fp12)
    np.testing.assert_allclose(a, b, atol=1e-06)
    np.testing.assert_allclose(a, Ph.alpha13_np(Fp12, Fp11), atol=1e-06)


def test_alpha23_uses_fp22_and_fp21(rng):
    Fp22 = rng.standard_normal((4, 8, 8)).astype(np.float32)
    Fp21 = rng.standard_normal((4, 8, 8)).astype(np.float32)
    a = Ph.gnd_field_np("fp_22", Fp22, Fp21)
    b = Ph.gnd_field_np("fp_21", Fp21, Fp22)
    np.testing.assert_allclose(a, b, atol=1e-06)
    np.testing.assert_allclose(a, Ph.alpha23_np(Fp22, Fp21), atol=1e-06)


def test_torch_matches_numpy(rng):
    Fp12 = rng.standard_normal((3, 9, 11)).astype(np.float32)
    Fp11 = rng.standard_normal((3, 9, 11)).astype(np.float32)
    np_val = Ph.alpha13_np(Fp12, Fp11)
    t_val = Ph.alpha13_torch(torch.from_numpy(Fp12), torch.from_numpy(Fp11)).numpy()
    np.testing.assert_allclose(np_val, t_val, atol=1e-05)


def test_consistency_loss_true_partner_cancels_algebraically(rng):
    own_pred = torch.from_numpy(rng.standard_normal((4, 10, 10)).astype(np.float32))
    own_true = torch.from_numpy(rng.standard_normal((4, 10, 10)).astype(np.float32))
    partner_a = torch.from_numpy(rng.standard_normal((4, 10, 10)).astype(np.float32))
    partner_b = torch.from_numpy(rng.standard_normal((4, 10, 10)).astype(np.float32) * 100)
    la = Ph.gnd_consistency_loss_torch("fp_12", own_pred, own_true, partner_a)
    lb = Ph.gnd_consistency_loss_torch("fp_12", own_pred, own_true, partner_b)
    assert torch.allclose(la, lb, atol=1e-05)
    direct = Ph.gnd_directional_term_torch("fp_12", own_pred, own_true)
    assert torch.allclose(la, direct, atol=1e-05)


@pytest.mark.parametrize("comp,axis", [("fp_12", -2), ("fp_22", -2), ("fp_11", -1), ("fp_21", -1)])
def test_directional_term_zero_iff_error_constant_along_its_axis(comp, axis, rng):
    H, W = (8, 8)
    other = -1 if axis == -2 else -2
    base = rng.standard_normal((2, H if other == -2 else 1, W if other == -1 else 1))
    err_const_along_axis = np.broadcast_to(base, (2, H, W)).copy()
    pred = torch.from_numpy(err_const_along_axis.astype(np.float32))
    y = torch.zeros_like(pred)
    term0 = Ph.gnd_directional_term_torch(comp, pred, y)
    assert term0.item() < 1e-10
    varying = np.zeros((2, H, W), np.float32)
    [slice(None)] * 3
    if axis == -2:
        for i in range(H):
            varying[:, i, :] = i
    else:
        for j in range(W):
            varying[:, :, j] = j
    predv = torch.from_numpy(varying)
    term1 = Ph.gnd_directional_term_torch(comp, predv, y)
    assert term1.item() > 1e-06


def test_gnd_report_from_predictions_model_partner(rng):
    N, H, W = (5, 10, 10)
    Fp11_true = rng.standard_normal((N, H, W)).astype(np.float32)
    Fp12_true = rng.standard_normal((N, H, W)).astype(np.float32)
    noise = 0.05 * rng.standard_normal((N, H, W)).astype(np.float32)
    Fp12_pred = Fp12_true + noise
    Fp11_pred = Fp11_true.copy()
    comp_fields = {
        "fp_12": {"true": Fp12_true, "pred": Fp12_pred},
        "fp_11": {"true": Fp11_true, "pred": Fp11_pred},
    }
    rep = Ph.gnd_report_from_predictions(comp_fields)
    assert "alpha13" in rep and "alpha23" not in rep
    assert rep["alpha13"]["partner_source"] == "model"
    expect_true = Ph.alpha13_np(Fp12_true, Fp11_true)
    expect_pred = Ph.alpha13_np(Fp12_pred, Fp11_pred)
    expect_rmse = float(np.sqrt(((expect_pred - expect_true) ** 2).mean()))
    assert rep["alpha13"]["rmse"] == pytest.approx(expect_rmse, rel=1e-05)
    assert 0.0 < rep["alpha13"]["r2"] <= 1.0


def test_gnd_report_from_predictions_ground_truth_partner(rng):
    N, H, W = (5, 10, 10)
    Fp22_true = rng.standard_normal((N, H, W)).astype(np.float32)
    Fp22_pred = Fp22_true + 0.1 * rng.standard_normal((N, H, W)).astype(np.float32)
    Fp21_true = rng.standard_normal((N, H, W)).astype(np.float32)
    comp_fields = {"fp_22": {"true": Fp22_true, "pred": Fp22_pred}, "fp_21": {"true": Fp21_true}}
    rep = Ph.gnd_report_from_predictions(comp_fields)
    assert rep["alpha23"]["partner_source"] == "ground_truth"
    expect_true = Ph.alpha23_np(Fp22_true, Fp21_true)
    expect_pred = Ph.alpha23_np(Fp22_pred, Fp21_true)
    expect_rmse = float(np.sqrt(((expect_pred - expect_true) ** 2).mean()))
    assert rep["alpha23"]["rmse"] == pytest.approx(expect_rmse, rel=1e-05)


def test_gnd_report_skips_term_when_primary_component_absent():
    rep = Ph.gnd_report_from_predictions({"fp_11": {"true": np.zeros((2, 4, 4))}})
    assert rep == {}
