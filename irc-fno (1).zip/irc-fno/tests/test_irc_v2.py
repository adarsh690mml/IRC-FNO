import json
import os
import subprocess
import sys

import numpy as np
import pandas as pd
import pytest
import torch
from scipy.ndimage import gaussian_filter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from irc import data as Dm
from irc import metrics as Mm
from irc import spectral as Sp
from irc import uq as Uq
from irc.model import DescriptorFNO, SpectralConv2d, count_params, forward_flops, target_width
from irc.pipeline import partial_load
from irc.train import FieldDataset, spectral_term


def binary_micro(rng, N, H, W, sigma=2.0):
    f = gaussian_filter(rng.standard_normal((N, H, W)), (0, sigma, sigma), mode="wrap")
    return (f > np.quantile(f, 0.8, axis=(1, 2), keepdims=True)).astype(np.float32)


@pytest.fixture
def rng():
    return np.random.default_rng(7)


def test_original_descriptors_have_dead_channels_and_v2_fixes_them(rng):
    X = binary_micro(rng, 3, 24, 24)[..., None]
    assert Dm.dead_channels(Dm.build_descriptor_array(X, version="v1")) == [1, 11]
    assert Dm.dead_channels(Dm.build_descriptor_array(X, version="v2")) == []


def test_v2_spectralconv_caps_modes_and_uses_both_blocks():
    torch.manual_seed(0)
    layer = SpectralConv2d(2, 2, modes1=16, modes2=5)
    assert layer.effective_modes(16, 16) == (8, 5)
    x = torch.randn(1, 2, 16, 16)
    y1 = layer(x)
    with torch.no_grad():
        layer.w_pos.add_(torch.randn_like(layer.w_pos))
    assert not torch.allclose(layer(x), y1)


def test_v2_spectralconv_matches_manual_reference():
    torch.manual_seed(1)
    H, W, m1, m2 = (12, 10, 4, 3)
    layer = SpectralConv2d(1, 1, m1, m2)
    x = torch.randn(1, 1, H, W)
    xf = np.fft.rfft2(x.numpy()[0, 0], norm="ortho")
    wp = (
        layer.w_pos.detach().numpy()[0, 0, ..., 0] + 1j * layer.w_pos.detach().numpy()[0, 0, ..., 1]
    )
    wn = (
        layer.w_neg.detach().numpy()[0, 0, ..., 0] + 1j * layer.w_neg.detach().numpy()[0, 0, ..., 1]
    )
    of = np.zeros_like(xf)
    of[:m1, :m2] = xf[:m1, :m2] * wp
    of[H - m1 :, :m2] = xf[H - m1 :, :m2] * wn
    ref = np.fft.irfft2(of, s=(H, W), norm="ortho")
    assert np.allclose(layer(x).detach().numpy()[0, 0], ref, atol=1e-05)


def test_effective_params_exclude_dead_weights():
    m = DescriptorFNO(modes1=40, modes2=10, width=8, n_layers=2, desc_channels=5)
    p = count_params(m, 32, 32)
    assert p["effective"] < p["allocated"]
    m2 = DescriptorFNO(modes1=16, modes2=10, width=8, n_layers=2, desc_channels=5)
    assert count_params(m2, 32, 32)["effective"] == p["effective"]
    assert forward_flops(m, 32, 32) == forward_flops(m2, 32, 32)
    assert target_width(4 * 4 * 16 * 12 * 32**2, 16, 12, 4) == 32


@pytest.mark.parametrize("H,W", [(100, 100), (33, 30), (32, 48), (31, 31)])
def test_energy_table_equals_projection_onto_representable_set(rng, H, W):
    f = rng.standard_normal((3, H, W))
    T = Sp.fno_block_energy_table(Sp.mean_power(f), W)
    Fh, Wf = (np.fft.rfft2(f), W // 2 + 1)
    for m1, m2 in [(1, 1), (5, 7), (H // 2, Wf), (H // 3, W // 4), (H // 2, 3)]:
        ri, rs = Sp.representable_row_masks(H, m1)
        M = np.zeros((H, Wf))
        M[ri, :m2] = 1
        M[:, 0] = rs
        if W % 2 == 0 and m2 == Wf:
            M[:, -1] = rs
        g = np.fft.irfft2(Fh * M, s=(H, W))
        assert abs(((f - g) * g).sum()) < 1e-08 * (f**2).sum()
        assert np.isclose(T[m1 - 1, m2 - 1], (g**2).sum() / 3 * H * W, rtol=1e-10)


def test_selector_is_isotropic_for_isotropic_fields_and_respects_limits(rng):
    w = rng.standard_normal((10, 100, 100))
    s = Sp.select_modes(w, 0.8)
    assert abs(s["m1"] - s["m2"]) <= 3 and s["m1"] <= 50 and (s["captured"] >= 0.8)
    s2 = Sp.select_modes(w, 0.99, max_modes=(20, 20))
    assert not s2["reachable"] and (s2["m1"], s2["m2"]) == (20, 20)
    smooth = gaussian_filter(w, (0, 3, 3), mode="wrap")
    assert Sp.select_modes(smooth, 0.8)["m1"] < s["m1"]
    aniso = Sp.select_modes(gaussian_filter(w, (0, 4, 0.5), mode="wrap"), 0.8)
    assert aniso["m1"] < aniso["m2"] / 2


def test_spectral_term_scaled_to_mse():
    rng = np.random.default_rng(0)
    target = gaussian_filter(rng.standard_normal((6, 24, 20)), (0, 2, 2), mode="wrap")
    target -= target.mean(axis=(1, 2), keepdims=True)
    mask = torch.from_numpy(Sp.frequency_mask(target))
    t = torch.from_numpy(target).float()
    pred = torch.zeros_like(t)
    mse = ((pred - t) ** 2).mean().item()
    assert np.isclose(spectral_term(pred, t, mask).item(), mse, rtol=0.05)


def test_splits_disjoint_stratified_grouped(tmp_path):
    N = 400
    strata = Dm.strata_from_blocks(N, 4)
    groups = np.arange(N) // 2
    s = Dm.make_splits(N, (0.7, 0.1, 0.1, 0.1), seed=3, groups=groups, strata=strata)
    allidx = np.concatenate(list(s.values()))
    assert len(allidx) == N and len(np.unique(allidx)) == N
    for v in s.values():
        assert len(set(groups[v]) & set(groups[np.setdiff1d(allidx, v)])) == 0
        c = np.bincount(strata[v], minlength=4)
        assert c.max() - c.min() <= 2
    p = tmp_path / "split.json"
    Dm.save_split(str(p), s, {})
    s2, _ = Dm.load_split(str(p), N)
    assert all((np.array_equal(s[k], s2[k]) for k in s))
    with pytest.raises(FileExistsError):
        Dm.save_split(str(p), s, {})


@pytest.mark.parametrize("version", ["v1", "v2"])
def test_descriptor_permutations_make_augmentation_equivariant(rng, version):
    ops = Dm.AUG_GROUPS["uniaxial_x"]
    perms = Dm.derive_descriptor_perms(ops, 1, (0.8, 1.2, 2.0), True, 2, version=version)
    X = binary_micro(rng, 2, 32, 32)[..., None]
    D = Dm.build_descriptor_array(X, version=version)
    for op in ops:
        Dt = Dm.build_descriptor_array(
            np.ascontiguousarray(Dm.spatial_op(X, op, (1, 2))), version=version
        )
        assert np.allclose(Dt, Dm.spatial_op(D, op, (1, 2))[..., perms[op]], atol=0.0001)


def test_unpermuted_flip_corrupts_directional_channels(rng):
    X = binary_micro(rng, 1, 32, 32)[..., None]
    D = Dm.build_descriptor_array(X, version="v2")
    Dt = Dm.build_descriptor_array(np.ascontiguousarray(X[:, ::-1]), version="v2")
    assert not np.allclose(Dt, D[:, ::-1], atol=0.001)


@pytest.mark.parametrize(
    "comp,op,sign",
    [
        ("fp_12", "flip_h", -1),
        ("fp_12", "flip_w", -1),
        ("fp_12", "rot180", 1),
        ("fp_11", "flip_h", 1),
    ],
)
def test_dataset_tensor_sign_with_normalisation_offset(rng, comp, op, sign):
    N, H, W = (2, 8, 8)
    y = 0.01 * rng.standard_normal((N, H, W)) + 0.003
    mu, sg = (float(y.mean()), float(y.std()))
    X = binary_micro(rng, N, H, W, 1.0)[..., None]
    D = rng.standard_normal((N, H, W, 15)).astype(np.float32)
    perms = {op: np.arange(15)}
    ds = FieldDataset(
        X,
        D,
        (y - mu) / sg,
        comp,
        state=(y - mu) / sg,
        y_offset=mu / sg,
        state_offset=mu / sg,
        ops=(op,),
        desc_perms=perms,
        augment=True,
    )
    x, d, yz, s = ds[0]
    want = sign * Dm.spatial_op(y[0], op, (0, 1))
    assert np.allclose(yz.numpy() * sg + mu, want, atol=1e-06)
    assert np.allclose(s[0].numpy() * sg + mu, want, atol=1e-06)
    assert np.allclose(x.numpy()[0], Dm.spatial_op(X[0, ..., 0], op, (0, 1)))


@pytest.mark.parametrize("op", ["flip_h", "flip_w", "rot180"])
def test_dataset_augmented_descriptors_equal_recomputed(rng, op):
    X = binary_micro(rng, 1, 32, 32)[..., None]
    D = Dm.build_descriptor_array(X, version="v2")
    perms = Dm.derive_descriptor_perms(Dm.AUG_GROUPS["uniaxial_x"], 1, (0.8, 1.2, 2.0), True, 2)
    ds = FieldDataset(
        X, D, np.zeros((1, 32, 32)), "fp_11", ops=(op,), desc_perms=perms, augment=True
    )
    _, d, _, _ = ds[0]
    Dt = Dm.build_descriptor_array(np.ascontiguousarray(Dm.spatial_op(X, op, (1, 2))), version="v2")
    assert np.allclose(d.numpy(), Dt[0].transpose(2, 0, 1), atol=0.0001)


def test_fieldwise_conformal_coverage_is_valid():
    rng = np.random.default_rng(0)
    covs = []
    for _ in range(300):

        def fields(n):
            sd = rng.uniform(0.5, 2.0, (n, 6, 6))
            return (rng.standard_normal((n, 6, 6)) * sd, np.zeros((n, 6, 6)), sd)

        y_c, p_c, s_c = fields(40)
        y_t, p_t, s_t = fields(40)
        r = Uq.calibrate_and_evaluate(y_c, p_c, s_c, y_t, p_t, s_t, 0.9)
        covs.append(r["fieldwise"]["test_field_coverage"])
    assert np.mean(covs) >= 0.9 - 0.01
    assert Uq.conformal_quantile(np.arange(5), 0.95) == float("inf")


def test_signed_distance_and_interface_profile():
    ph = np.zeros((20, 20), bool)
    ph[5:15, 5:15] = True
    d = Mm.signed_interface_distance(ph)
    assert d[10, 10] == 5 and d[0, 0] < 0 and (d[5, 10] == 1) and (d[4, 10] == -1)
    y = np.random.default_rng(0).standard_normal((2, 20, 20))
    prof = Mm.interface_profile(y, y + 0.1, np.stack([ph, ph]))
    assert sum((r["n"] for r in prof)) == y.size
    assert all((np.isclose(r["rmse"], 0.1) for r in prof if r["n"]))


def test_global_metrics_use_increment():
    y = 1.0 + 0.01 * np.random.default_rng(0).standard_normal((3, 8, 8))
    m = Mm.global_metrics(y, y + 0.001, "fp_11")
    assert np.isclose(m["relL2_increment"], 0.001 / np.sqrt(((y - 1) ** 2).mean()), rtol=1e-06)
    assert np.isclose(m["R2"], 1 - 1e-06 / y.var(), rtol=1e-06)


def test_partial_load_and_state_input_shapes():
    a = DescriptorFNO(modes1=6, modes2=6, width=8, n_layers=2, desc_channels=5)
    b = DescriptorFNO(modes1=4, modes2=6, width=8, n_layers=2, desc_channels=5, state_channels=1)
    n, t = partial_load(b, a.state_dict())
    assert 0 < n < t
    out = b(torch.randn(2, 1, 16, 16), torch.randn(2, 5, 16, 16), torch.randn(2, 1, 16, 16))
    assert out.shape == (2, 16, 16)
    with pytest.raises(ValueError):
        b(torch.randn(2, 1, 16, 16), torch.randn(2, 5, 16, 16))


def test_data_convention_report_flags_invalid_physics():
    rng = np.random.default_rng(0)
    e = 0.02 * rng.random((5, 8, 8))
    F = np.zeros((5, 8, 8, 3, 3))
    F[..., 0, 0] = 1 + e
    F[..., 1, 1] = F[..., 2, 2] = 1 / np.sqrt(1 + e)
    F[..., 0, 1] = 0.01 * e
    rep = Dm.data_convention_report(F)
    assert rep["abs_det3_minus_1_max"] < 1e-12
    assert rep["abs_det2_minus_1_max"] > 0.001
    assert rep["rms_fp12_minus_fp21_over_rms_fp12"] > 0.5


def _write_plasticity_dataset(root, material_model, morphologies, n_per_morph, H=16, W=16, seed=0):
    rng = np.random.default_rng(seed)
    mdir = os.path.join(root, material_model)
    for j, morph in enumerate(morphologies):
        n = n_per_morph + j
        d = os.path.join(mdir, morph)
        os.makedirs(d, exist_ok=True)
        f = gaussian_filter(rng.standard_normal((n, H, W)), (0, 2.0, 2.0), mode="wrap")
        X = (f > np.quantile(f, 0.75, axis=(1, 2), keepdims=True)).astype(np.float32)
        fp = np.zeros((n, H, W, 3, 3), np.float32)
        e = 0.01 * (j + 1) * X
        fp[..., 0, 0] = 1 + e
        fp[..., 1, 1] = 1 / np.sqrt(1 + e)
        fp[..., 2, 2] = 1 / np.sqrt(1 + e)
        fp[..., 0, 1] = 0.005 * e
        key = morph.lower()
        np.save(os.path.join(d, f"input_phase_{key}.npy"), X)
        np.save(os.path.join(d, f"Fp_{key}.npy"), fp)


def test_load_plasticity_material_concatenates_with_exact_labels(tmp_path):
    root = str(tmp_path / "PLASTICITY DATA")
    morphs = ["Bicontinuous", "Elongated", "Inclusion", "Random"]
    _write_plasticity_dataset(root, "Isotropic", morphs, n_per_morph=5)
    X, fp, labels, names = Dm.load_plasticity_material(root, "Isotropic", morphs)
    assert names == morphs
    assert len(X) == len(fp) == len(labels) == 5 + 6 + 7 + 8
    assert fp.shape[1:] == (16, 16, 3, 3)
    assert labels.tolist() == [0] * 5 + [1] * 6 + [2] * 7 + [3] * 8
    assert np.bincount(labels).tolist() == [5, 6, 7, 8]


def test_load_plasticity_material_missing_folder_raises(tmp_path):
    root = str(tmp_path / "PLASTICITY DATA")
    _write_plasticity_dataset(root, "Isotropic", ["Bicontinuous"], n_per_morph=3)
    with pytest.raises(FileNotFoundError):
        Dm.load_plasticity_material(root, "Linear", ["Bicontinuous"])
    with pytest.raises(FileNotFoundError):
        Dm.load_plasticity_material(root, "Isotropic", ["Bicontinuous", "Random"])


def test_discover_material_models_finds_only_existing_subfolders(tmp_path):
    root = str(tmp_path / "PLASTICITY DATA")
    _write_plasticity_dataset(root, "Isotropic", ["Bicontinuous"], n_per_morph=3)
    _write_plasticity_dataset(root, "Power Law", ["Bicontinuous"], n_per_morph=3)
    found = Dm.discover_material_models(root)
    assert found == ["Isotropic", "Power Law"]


@pytest.mark.parametrize(
    "extra",
    [
        [],
        ["--mode", "base"],
        [
            "--set",
            'augment="uniaxial_x"',
            "res_state_input=true",
            "crossfit_folds=0",
            'alpha_policy="val_ls"',
        ],
    ],
)
def test_smoke_end_to_end(tmp_path, extra):
    out = str(tmp_path / "run")
    cmd = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_irc.py"),
        "--smoke",
        "--cpu",
        "--out",
        out,
        "--components",
        "fp_12",
    ] + extra
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    cdir = os.path.join(out, "fp_12_seed0")
    rep = json.load(open(os.path.join(cdir, "test_report.json")))
    assert rep["manifest_reload_max_abs_diff"] < 1e-06
    man = json.load(open(os.path.join(cdir, "manifest.json")))
    assert len(man["correctors"]) == rep["n_accepted"]
    split = json.load(open(os.path.join(out, "split.json")))
    sets = [set(split[k]) for k in ("train", "val", "calib", "test")]
    assert sum((len(s) for s in sets)) == len(set().union(*sets))
    if "--mode" in extra:
        assert rep["n_accepted"] == 0 and rep["accounting"]["n_forward_passes"] == 1
    r2 = subprocess.run(cmd, capture_output=True, text=True)
    assert r2.returncode != 0


def test_smoke_end_to_end_gnd_lambda_and_report(tmp_path):
    out = str(tmp_path / "run")
    cmd = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_irc.py"),
        "--smoke",
        "--cpu",
        "--out",
        out,
        "--components",
        "fp_11",
        "fp_12",
        "--set",
        "gnd_lambda=0.05",
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    rep_path = os.path.join(out, "gnd_report_seed0.json")
    assert os.path.exists(rep_path)
    rep = json.load(open(rep_path))
    assert "alpha13" in rep
    assert rep["alpha13"]["components"] == ["fp_12", "fp_11"]
    assert rep["alpha13"]["partner_source"] == "model"
    assert rep["alpha13"]["rmse"] >= 0.0


def test_smoke_end_to_end_plasticity_root_multi_model(tmp_path):
    root = str(tmp_path / "PLASTICITY DATA")
    morphs = ["Bicontinuous", "Elongated", "Inclusion", "Random"]
    for model in ("Isotropic", "Power Law"):
        _write_plasticity_dataset(
            root, model, morphs, n_per_morph=10, H=16, W=16, seed=hash(model) % 1000
        )
    out = str(tmp_path / "run")
    cmd = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_irc.py"),
        "--cpu",
        "--out",
        out,
        "--plasticity-root",
        root,
        "--material-models",
        "Isotropic",
        "Power Law",
        "--components",
        "fp_12",
        "--seeds",
        "0",
        "--set",
        "epochs=3",
        "res_epochs=2",
        "max_iter=2",
        "crossfit_folds=2",
        "batch_size=4",
        "modes1=4",
        "modes2=4",
        "width=8",
        "n_layers=2",
        "res_width=8",
        "res_n_layers=2",
        "T_0=2",
        "log_every=1",
        "early_stop_patience=None",
        "mc_samples=3",
        "tol_r2=-1.0",
        "res_r2_floor=-1e9",
    ]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    for model, slug in (("Isotropic", "Isotropic"), ("Power Law", "Power_Law")):
        mdir = os.path.join(out, slug)
        split = json.load(open(os.path.join(mdir, "split.json")))
        assert split["meta"]["material_model"] == model
        assert split["meta"]["stratified"] is True
        sets = [set(split[k]) for k in ("train", "val", "calib", "test")]
        assert sum((len(s) for s in sets)) == len(set().union(*sets)) == split["meta"]["N"]
        assert os.path.exists(os.path.join(mdir, "summary.csv"))
        assert os.path.exists(os.path.join(mdir, "fp_12_seed0", "test_report.json"))
    df_all = pd.read_csv(os.path.join(out, "summary_all.csv"))
    assert set(df_all["material_model"]) == {"Isotropic", "Power Law"}
    assert len(df_all) == 2
