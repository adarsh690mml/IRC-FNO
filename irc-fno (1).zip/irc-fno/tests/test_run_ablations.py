import os
import subprocess
import sys

import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def _make_legacy_dataset(data_dir, n=30, h=16, w=16, seed=0):
    rng = np.random.default_rng(seed)
    X = np.zeros((n, h, w), np.float32)
    fp = np.zeros((n, h, w, 3, 3), np.float32)
    for i in range(n):
        f = gaussian_filter(rng.standard_normal((h, w)), 2.0, mode="wrap")
        X[i] = (f > np.quantile(f, 0.75)).astype(np.float32)
        e = 0.02 * X[i]
        fp[i, :, :, 0, 0] = 1 + e
        fp[i, :, :, 1, 1] = fp[i, :, :, 2, 2] = 1 / np.sqrt(1 + e)
        fp[i, :, :, 0, 1] = 0.01 * e
    os.makedirs(data_dir, exist_ok=True)
    np.save(os.path.join(data_dir, "texture_combined.npy"), X)
    np.save(os.path.join(data_dir, "fp_combined.npy"), fp)


def test_run_ablations_end_to_end(tmp_path):
    data_dir = str(tmp_path / "data")
    _make_legacy_dataset(data_dir)
    out = str(tmp_path / "ablrun")
    fast = [
        "epochs=3",
        "res_epochs=2",
        "max_iter=1",
        "crossfit_folds=0",
        "batch_size=4",
        "modes1=4",
        "modes2=4",
        "width=8",
        "n_layers=2",
        "res_width=8",
        "res_n_layers=2",
        "T_0=2",
        "log_every=1",
        "early_stop_patience=None",
        "mc_samples=3",
        "tol_r2=-1.0",
        "res_r2_floor=-1e9",
    ]
    cmd = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_ablations.py"),
        "--out",
        out,
        "--data-path",
        data_dir,
        "--components",
        "fp_12",
        "--seeds",
        "0",
        "--cpu",
        "--skip",
        "E4_fixed_modes",
        "E5_state_input",
        "E7_descriptor_v1",
        "--extra-set",
    ] + fast
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    assert os.path.exists(os.path.join(out, "E1_irc", "fp_12_seed0", "test_report.json"))
    assert os.path.exists(os.path.join(out, "E3_no_crossfit", "fp_12_seed0", "test_report.json"))
    assert os.path.exists(
        os.path.join(out, "E8_no_spectral_loss", "fp_12_seed0", "test_report.json")
    )
    df = pd.read_csv(os.path.join(out, "ablation_report", "ablation_summary.csv"))
    assert set(df["ablation"]) == {"E3_no_crossfit", "E8_no_spectral_loss"}
    assert df["delta_R2_vs_baseline"].notna().all()


def test_run_ablations_skips_already_completed_run(tmp_path):
    data_dir = str(tmp_path / "data")
    _make_legacy_dataset(data_dir)
    out = str(tmp_path / "ablrun")
    fast = [
        "epochs=2",
        "res_epochs=1",
        "max_iter=1",
        "crossfit_folds=0",
        "batch_size=4",
        "modes1=4",
        "modes2=4",
        "width=8",
        "n_layers=2",
        "res_width=8",
        "res_n_layers=2",
        "T_0=2",
        "log_every=1",
        "early_stop_patience=None",
        "mc_samples=3",
        "tol_r2=-1.0",
        "res_r2_floor=-1e9",
    ]
    common = [
        sys.executable,
        os.path.join(ROOT, "scripts", "run_ablations.py"),
        "--out",
        out,
        "--data-path",
        data_dir,
        "--components",
        "fp_12",
        "--seeds",
        "0",
        "--cpu",
        "--skip",
        "E3_no_crossfit",
        "E4_fixed_modes",
        "E5_state_input",
        "E7_descriptor_v1",
        "E8_no_spectral_loss",
        "--extra-set",
    ] + fast
    r1 = subprocess.run(common, capture_output=True, text=True, timeout=900)
    assert r1.returncode == 0, r1.stdout[-2000:]
    mtime1 = os.path.getmtime(os.path.join(out, "E1_irc", "fp_12_seed0", "test_report.json"))
    r2 = subprocess.run(common, capture_output=True, text=True, timeout=900)
    assert r2.returncode == 0, r2.stdout[-2000:]
    assert "already exists and is non-empty -- skipping" in r2.stdout
    mtime2 = os.path.getmtime(os.path.join(out, "E1_irc", "fp_12_seed0", "test_report.json"))
    assert mtime1 == mtime2
