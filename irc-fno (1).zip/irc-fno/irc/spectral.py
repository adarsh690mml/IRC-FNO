import numpy as np


def rfft_multiplicity(W):
    m = np.full(W // 2 + 1, 2.0)
    m[0] = 1.0
    if W % 2 == 0:
        m[-1] = 1.0
    return m


def mean_power(fields):
    H, W = fields.shape[-2:]
    P = np.abs(np.fft.rfft2(fields, axes=(-2, -1))) ** 2
    return P.mean(axis=0) * rfft_multiplicity(W)[None, :]


def representable_row_masks(H, m1):
    j = np.arange(H)
    interior = (j < m1) | (j >= H - m1)
    selfconj = np.minimum(j, H - j) <= m1
    return (interior, selfconj)


def fno_block_energy_table(Pw, W=None):
    H, Wf = Pw.shape
    W = 2 * (Wf - 1) if W is None else W
    selfconj_cols = np.zeros(Wf, dtype=bool)
    selfconj_cols[0] = True
    if W % 2 == 0:
        selfconj_cols[-1] = True
    rows = np.empty((H // 2, Wf))
    for m1 in range(1, H // 2 + 1):
        ri, rs = representable_row_masks(H, m1)
        rows[m1 - 1] = np.where(selfconj_cols, Pw[rs].sum(0), Pw[ri].sum(0))
    return np.cumsum(rows, axis=1)


def select_modes(fields, coverage=0.8, min_modes=4, max_modes=None):
    H, W = fields.shape[-2:]
    Pw = mean_power(fields)
    total = Pw.sum()
    T = fno_block_energy_table(Pw, W) / max(total, 1e-300)
    lim1, lim2 = (H // 2, W // 2 + 1)
    if max_modes is not None:
        lim1, lim2 = (min(lim1, int(max_modes[0])), min(lim2, int(max_modes[1])))
    lo1, lo2 = (min(min_modes, lim1), min(min_modes, lim2))
    cands = []
    for m1 in range(lo1, lim1 + 1):
        for m2 in range(lo2, lim2 + 1):
            if T[m1 - 1, m2 - 1] >= coverage:
                cands.append((m1, m2, float(T[m1 - 1, m2 - 1])))
                break
    if not cands:
        m1, m2 = (lim1, lim2)
        return dict(
            m1=m1,
            m2=m2,
            captured=float(T[m1 - 1, m2 - 1]),
            coverage_target=coverage,
            reachable=False,
        )
    tie_tol = 0.02
    cmin = min((a * b for a, b, _ in cands))
    near = [c for c in cands if c[0] * c[1] <= (1 + tie_tol) * cmin]
    m1, m2, f = min(near, key=lambda c: (abs(c[0] / (H // 2) - c[1] / (W // 2 + 1)), c[0] * c[1]))
    return dict(m1=int(m1), m2=int(m2), captured=float(f), coverage_target=coverage, reachable=True)


def frequency_mask(fields):
    H, W = fields.shape[-2:]
    mult = rfft_multiplicity(W)[None, :]
    P = np.abs(np.fft.rfft2(fields, axes=(-2, -1))) ** 2
    P = P.mean(axis=0)
    P[0, 0] = 0.0
    norm = (mult * P * P).sum() / max((mult * P).sum(), 1e-300)
    w = P / max(norm, 1e-300)
    return (mult * w / (H * W)).astype(np.float32)


def band_energy_fractions(fields, edges=(0.0, np.pi / 3, 2 * np.pi / 3, np.inf)):
    H, W = fields.shape[-2:]
    Pw = mean_power(fields).copy()
    Pw[0, 0] = 0.0
    k1 = 2 * np.pi * np.fft.fftfreq(H)[:, None]
    k2 = 2 * np.pi * np.fft.rfftfreq(W)[None, :]
    k = np.sqrt(k1**2 + k2**2)
    tot = Pw.sum()
    return [
        float(Pw[(k > lo) & (k <= hi)].sum() / max(tot, 1e-300))
        for lo, hi in zip(edges[:-1], edges[1:])
    ]
