import numpy as np


def conformal_quantile(scores, coverage):
    s = np.sort(np.asarray(scores, dtype=float).ravel())
    n = len(s)
    k = int(np.ceil((n + 1) * coverage))
    if k > n:
        return float("inf")
    return float(s[k - 1])


def calibrate_and_evaluate(y_cal, p_cal, sd_cal, y_te, p_te, sd_te, coverage=0.95, eps_frac=0.1):
    if sd_cal is None:
        sd_cal, sd_te, eps = (np.ones_like(y_cal), np.ones_like(y_te), 0.0)
        kind = "constant"
    else:
        eps = eps_frac * float(np.median(sd_cal))
        kind = "mc_dropout_scaled"
    a_cal = np.abs(y_cal - p_cal) / (sd_cal + eps)
    a_te = np.abs(y_te - p_te) / (sd_te + eps)
    S_cal, S_te = (len(y_cal), len(y_te))
    q_f = conformal_quantile(a_cal.reshape(S_cal, -1).max(1), coverage)
    in_f = a_te <= q_f
    q_p = conformal_quantile(a_cal, coverage)
    in_p = a_te <= q_p
    width = lambda q, sd: float(np.mean(2 * q * (sd + eps)))
    return dict(
        scale=kind,
        eps=eps,
        coverage_target=coverage,
        n_calib=S_cal,
        n_test=S_te,
        fieldwise=dict(
            q=q_f,
            test_field_coverage=float(in_f.reshape(S_te, -1).all(1).mean()),
            test_pixel_coverage=float(in_f.mean()),
            mean_width=width(q_f, sd_te),
            guarantee="P(whole field covered) >= target, marginal over exchangeable samples",
        ),
        pixelwise=dict(
            q=q_p,
            test_pixel_coverage=float(in_p.mean()),
            test_field_coverage=float(in_p.reshape(S_te, -1).all(1).mean()),
            mean_width=width(q_p, sd_te),
            guarantee="none (pixels within a field are dependent); empirical only",
        ),
    )
