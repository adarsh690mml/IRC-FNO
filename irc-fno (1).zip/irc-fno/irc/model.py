import math

import torch
import torch.nn as nn
import torch.nn.functional as F


class SpectralConv2d(nn.Module):

    def __init__(self, in_channels, out_channels, modes1, modes2):
        super().__init__()
        self.in_channels, self.out_channels = (in_channels, out_channels)
        self.modes1, self.modes2 = (int(modes1), int(modes2))
        scale = 1.0 / (in_channels * out_channels)
        self.w_pos = nn.Parameter(scale * torch.randn(in_channels, out_channels, modes1, modes2, 2))
        self.w_neg = nn.Parameter(scale * torch.randn(in_channels, out_channels, modes1, modes2, 2))

    def effective_modes(self, H, W):
        return (min(self.modes1, H // 2), min(self.modes2, W // 2 + 1))

    def forward(self, x):
        with torch.autocast(device_type=x.device.type, enabled=False):
            x = x.float()
            B, C, H, W = x.shape
            m1, m2 = self.effective_modes(H, W)
            x_ft = torch.fft.rfft2(x, norm="ortho")
            out_ft = torch.zeros(
                B, self.out_channels, H, W // 2 + 1, dtype=torch.cfloat, device=x.device
            )
            wp = torch.view_as_complex(self.w_pos[:, :, :m1, :m2].contiguous())
            wn = torch.view_as_complex(self.w_neg[:, :, :m1, :m2].contiguous())
            out_ft[:, :, :m1, :m2] = torch.einsum("bixy,ioxy->boxy", x_ft[:, :, :m1, :m2], wp)
            out_ft[:, :, H - m1 :, :m2] = torch.einsum(
                "bixy,ioxy->boxy", x_ft[:, :, H - m1 :, :m2], wn
            )
            return torch.fft.irfft2(out_ft, s=(H, W), norm="ortho")


class GatedFNOBlock(nn.Module):

    def __init__(self, width, modes1, modes2, desc_dim, dropout=0.0):
        super().__init__()
        self.spec = SpectralConv2d(width, width, modes1, modes2)
        self.w = nn.Conv2d(width, width, 1)
        self.desc_proj = nn.Conv2d(desc_dim, width, 1)
        self.gate_proj = nn.Conv2d(desc_dim, width, 1)
        self.norm = nn.InstanceNorm2d(width, affine=True)
        self.dropout = nn.Dropout2d(dropout) if dropout > 0 else nn.Identity()

    def forward(self, x, desc_feat):
        gate = torch.sigmoid(self.gate_proj(desc_feat))
        r = self.spec(x) + self.w(x) + gate * self.desc_proj(desc_feat)
        return F.gelu(self.dropout(self.norm(r)))


class DescriptorFNO(nn.Module):

    def __init__(
        self,
        modes1=16,
        modes2=12,
        width=32,
        n_layers=4,
        in_channels=1,
        desc_channels=15,
        descriptor_dim=16,
        dropout=0.0,
        state_channels=0,
        use_global_skip=True,
    ):
        super().__init__()
        self.arch = dict(
            modes1=int(modes1),
            modes2=int(modes2),
            width=int(width),
            n_layers=int(n_layers),
            in_channels=int(in_channels),
            desc_channels=int(desc_channels),
            descriptor_dim=int(descriptor_dim),
            dropout=float(dropout),
            state_channels=int(state_channels),
            use_global_skip=bool(use_global_skip),
        )
        self.state_channels = state_channels
        self.use_global_skip = use_global_skip
        self.desc_encoder = nn.Sequential(
            nn.Conv2d(desc_channels, descriptor_dim * 2, 1),
            nn.GELU(),
            nn.Conv2d(descriptor_dim * 2, descriptor_dim, 1),
        )
        self.lifting = nn.Conv2d(in_channels + state_channels, width, 1)
        self.blocks = nn.ModuleList(
            [GatedFNOBlock(width, modes1, modes2, descriptor_dim, dropout) for _ in range(n_layers)]
        )
        self.fno_proj = nn.Sequential(
            nn.Conv2d(width, width * 2, 1), nn.GELU(), nn.Conv2d(width * 2, width, 1)
        )
        self.head = nn.Sequential(
            nn.Conv2d(width, width // 2, 1), nn.GELU(), nn.Conv2d(width // 2, 1, 1)
        )

    def forward(self, x, d, state=None):
        if self.state_channels:
            if state is None:
                raise ValueError("model was built with state_channels>0 but no state given")
            x = torch.cat([x, state], dim=1)
        df = self.desc_encoder(d)
        v = self.lifting(x)
        v0 = v
        for blk in self.blocks:
            v = blk(v, df)
        if self.use_global_skip:
            v = v + v0
        return self.head(self.fno_proj(v)).squeeze(1)


def build_model(arch):
    return DescriptorFNO(**arch)


def count_params(model, H=None, W=None):
    alloc = sum((p.numel() for p in model.parameters() if p.requires_grad))
    eff = alloc
    if H is not None:
        for m in model.modules():
            if isinstance(m, SpectralConv2d):
                m1, m2 = m.effective_modes(H, W)
                full = 2 * m.in_channels * m.out_channels * m.modes1 * m.modes2 * 2
                used = 2 * m.in_channels * m.out_channels * m1 * m2 * 2
                eff -= full - used
    return dict(allocated=int(alloc), effective=int(eff))


def forward_flops(model, H, W):
    HW = H * W
    fft = 5 * HW * math.log2(max(HW, 2))
    fl = 0.0
    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            fl += 2 * m.in_channels * m.out_channels * HW
        elif isinstance(m, SpectralConv2d):
            m1, m2 = m.effective_modes(H, W)
            fl += 2 * 8 * m.in_channels * m.out_channels * m1 * m2
            fl += fft * (m.in_channels + m.out_channels)
    return float(fl)


def target_width(target_params, modes1, modes2, n_layers):
    return max(4, int(round(math.sqrt(target_params / (4 * n_layers * modes1 * modes2)))))
