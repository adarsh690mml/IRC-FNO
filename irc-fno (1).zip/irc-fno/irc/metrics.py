import numpy as np
from scipy.ndimage import distance_transform_edt

DIST_BINS = (-np.inf, -8, -4, -2, -1, 0, 1, 2, 4, 8, np.inf)


def increment(y, comp_name):
    return y - 1.0 if comp_name in ("fp_11", "fp_22") else y


def global_metrics(y, p, comp_name):
    e = p - y
    yi = increment(y, comp_name)
    sse, n = (float((e**2).sum()), e.size)
    sst = float(((y - y.mean()) ** 2).sum())
    S = len(y)
    ef, yf = (e.reshape(S, -1), y.reshape(S, -1))
    with np.errstate(divide="ignore", invalid="ignore"):
        r2_s = 1 - (ef**2).sum(1) / ((yf - yf.mean(1, keepdims=True)) ** 2).sum(1)
        rel_s = np.sqrt((ef**2).sum(1) / (increment(yf, comp_name) ** 2).sum(1))
    return dict(
        R2=1 - sse / sst if sst > 0 else float("nan"),
        R2_sample_median=float(np.nanmedian(r2_s)),
        MSE=sse / n,
        RMSE=float(np.sqrt(sse / n)),
        MAE=float(np.abs(e).mean()),
        relL2_increment=float(np.sqrt(sse / max(float((yi**2).sum()), 1e-300))),
        relL2_increment_sample_mean=float(np.nanmean(rel_s)),
        max_abs_error=float(np.abs(e).max()),
        p99_abs_error=float(np.quantile(np.abs(e), 0.99)),
        peak_increment_rel_error=float(
            np.mean(
                np.abs(
                    np.abs(increment(p, comp_name)).reshape(S, -1).max(1)
                    - np.abs(yi).reshape(S, -1).max(1)
                )
                / (np.abs(yi).reshape(S, -1).max(1) + 1e-300)
            )
        ),
    )


def band_errors(y, p, edges=(0.0, np.pi / 3, 2 * np.pi / 3, np.inf)):
    H, W = y.shape[-2:]
    k1 = 2 * np.pi * np.fft.fftfreq(H)[:, None]
    k2 = 2 * np.pi * np.fft.fftfreq(W)[None, :]
    k = np.sqrt(k1**2 + k2**2)
    T = np.abs(np.fft.fft2(y)) ** 2
    E = np.abs(np.fft.fft2(p - y)) ** 2
    out = {}
    for name, lo, hi in zip(("low", "mid", "high"), edges[:-1], edges[1:]):
        m = (k > lo) & (k <= hi)
        out[f"band_relerr_{name}"] = float(np.sqrt(E[:, m].sum() / max(T[:, m].sum(), 1e-300)))
    return out


def signed_interface_distance(phase, periodic=True):
    ph = phase.astype(bool)
    if periodic:
        H, W = ph.shape
        t = np.tile(ph, (3, 3))
        d1 = distance_transform_edt(t)[H : 2 * H, W : 2 * W]
        d0 = distance_transform_edt(~t)[H : 2 * H, W : 2 * W]
    else:
        d1, d0 = (distance_transform_edt(ph), distance_transform_edt(~ph))
    return np.where(ph, d1, -d0)


def interface_profile(y, p, phases, periodic=True):
    dist = np.stack([signed_interface_distance(ph, periodic) for ph in phases])
    e2 = (p - y) ** 2
    rows = []
    for lo, hi in zip(DIST_BINS[:-1], DIST_BINS[1:]):
        m = (dist > lo) & (dist <= hi)
        rows.append(
            dict(
                lo=float(lo),
                hi=float(hi),
                n=int(m.sum()),
                rmse=float(np.sqrt(e2[m].mean())) if m.any() else float("nan"),
            )
        )
    return rows


def hotspot_errors(y, p, comp_name, fracs=(0.01, 0.05)):
    S = len(y)
    yi = np.abs(increment(y, comp_name)).reshape(S, -1)
    ae = np.abs(p - y).reshape(S, -1)
    out = {}
    for f in fracs:
        thr = np.quantile(yi, 1 - f, axis=1, keepdims=True)
        m = yi >= thr
        out[f"hotspot_top{int(f * 100)}pct_mae"] = float(ae[m].mean())
        out[f"hotspot_top{int(f * 100)}pct_rel"] = float(ae[m].mean() / max(yi[m].mean(), 1e-300))
    return out


def full_report(y, p, comp_name, phases=None, strata=None, periodic=True):
    rep = {
        **global_metrics(y, p, comp_name),
        **band_errors(y, p),
        **hotspot_errors(y, p, comp_name),
    }
    if phases is not None:
        rep["interface_profile"] = interface_profile(y, p, phases, periodic)
    if strata is not None:
        rep["per_class"] = {
            int(c): global_metrics(y[strata == c], p[strata == c], comp_name)
            for c in np.unique(strata)
        }
    return rep
