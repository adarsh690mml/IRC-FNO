import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class _ConvBlock(nn.Module):

    def __init__(self, cin, cout):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1, padding_mode="circular"),
            nn.GroupNorm(1, cout),
            nn.GELU(),
            nn.Conv2d(cout, cout, 3, padding=1, padding_mode="circular"),
            nn.GroupNorm(1, cout),
            nn.GELU(),
        )

    def forward(self, x):
        return self.net(x)


class UNetRefiner(nn.Module):

    def __init__(self, in_channels=1, width=16, depth=2):
        super().__init__()
        chs = [width * 2**i for i in range(depth + 1)]
        self.inc = _ConvBlock(in_channels + 1, chs[0])
        self.downs = nn.ModuleList([_ConvBlock(chs[i], chs[i + 1]) for i in range(depth)])
        self.ups = nn.ModuleList(
            [_ConvBlock(chs[i + 1] + chs[i], chs[i]) for i in reversed(range(depth))]
        )
        self.outc = nn.Conv2d(chs[0], 1, 1)

    def forward(self, x, h):
        z = self.inc(torch.cat([x, h], dim=1))
        skips = [z]
        cur = z
        for down in self.downs:
            cur = F.avg_pool2d(cur, 2, ceil_mode=True)
            cur = down(cur)
            skips.append(cur)
        skips = skips[:-1]
        for up, skip in zip(self.ups, reversed(skips)):
            cur = F.interpolate(cur, size=skip.shape[-2:], mode="nearest")
            cur = up(torch.cat([cur, skip], dim=1))
        return self.outc(cur)


@torch.no_grad()
def refiner_flops(phi, H, W, in_channels=1):
    total = [0]

    def hook(m, inp, out):
        kh, kw = m.kernel_size
        total[0] += (
            2
            * (m.in_channels // m.groups)
            * kh
            * kw
            * m.out_channels
            * out.shape[-2]
            * out.shape[-1]
        )

    hs = [m.register_forward_hook(hook) for m in phi.modules() if isinstance(m, nn.Conv2d)]
    dev = next(phi.parameters()).device
    phi(torch.zeros(1, in_channels, H, W, device=dev), torch.zeros(1, 1, H, W, device=dev))
    for h in hs:
        h.remove()
    return int(total[0])


def progressive_spectral_loss(h, y, k, K, lam_start=0.5, lam_end=4.0):
    H, W = h.shape[-2:]
    Hh = torch.fft.rfft2(h.float(), dim=(-2, -1))
    Yh = torch.fft.rfft2(y.float(), dim=(-2, -1))
    k1 = torch.fft.fftfreq(H, device=h.device).abs().reshape(-1, 1)
    k2 = torch.fft.rfftfreq(W, device=h.device).abs().reshape(1, -1)
    omega = torch.sqrt(k1**2 + k2**2)
    omega_nyq = omega.max().clamp_min(1e-12)
    lam_k = lam_start + (lam_end - lam_start) * (max(k, 1) - 1) / max(K - 1, 1)
    rho = 1.0 + (omega / omega_nyq) ** lam_k
    rho_bar = rho.mean().clamp_min(1e-12)
    diff2 = (Hh.abs() - Yh.abs()) ** 2
    return (rho * diff2).mean() / rho_bar


def rollout(phi, x, h0, K, alpha, y=None, collect=False):
    h = h0
    traj = []
    for _ in range(K):
        h = h + alpha * phi(x, h)
        if collect:
            traj.append(h)
    return (h, traj) if collect else h


def train_irno(phi, x_tr, y_tr, h0_tr, x_va, y_va, h0_va, cfg, device, log=print):
    phi = phi.to(device)
    opt = torch.optim.AdamW(phi.parameters(), lr=cfg["irno_lr"], weight_decay=cfg["irno_wd"])
    K, alpha = (cfg["irno_K"], cfg["irno_alpha"])
    n = x_tr.shape[0]
    bs = cfg["irno_batch_size"]
    hist = {k: [] for k in ("epoch", "train_loss", "val_mse_K")}
    best_val, best_state = (np.inf, None)
    t0 = time.perf_counter()
    g = torch.Generator().manual_seed(cfg.get("seed", 0))
    for epoch in range(1, cfg["irno_epochs"] + 1):
        phi.train()
        perm = torch.randperm(n, generator=g)
        tot, nb = (0.0, 0)
        for i in range(0, n, bs):
            idx = perm[i : i + bs]
            xb, yb, h0b = (x_tr[idx].to(device), y_tr[idx].to(device), h0_tr[idx].to(device))
            opt.zero_grad(set_to_none=True)
            _, traj = rollout(phi, xb, h0b, K, alpha, yb, collect=True)
            l_spatial = torch.stack([F.mse_loss(hk, yb) for hk in traj]).mean()
            l_spectral = torch.stack(
                [progressive_spectral_loss(hk, yb, k + 1, K) for k, hk in enumerate(traj)]
            ).mean()
            l_fp = (phi(xb, yb) ** 2).mean()
            loss = l_spatial + cfg["irno_beta_spectral"] * l_spectral + cfg["irno_beta_fp"] * l_fp
            if not torch.isfinite(loss):
                continue
            loss.backward()
            nn.utils.clip_grad_norm_(phi.parameters(), cfg.get("irno_clip_grad_norm", 1.0))
            opt.step()
            tot += loss.item()
            nb += 1
        phi.eval()
        with torch.no_grad():
            hK = rollout(phi, x_va.to(device), h0_va.to(device), K, alpha)
            val_mse = F.mse_loss(hK, y_va.to(device)).item()
        hist["epoch"].append(epoch)
        hist["train_loss"].append(tot / max(nb, 1))
        hist["val_mse_K"].append(val_mse)
        if val_mse < best_val:
            best_val = val_mse
            best_state = {k: v.detach().cpu().clone() for k, v in phi.state_dict().items()}
        if epoch == 1 or epoch % cfg.get("irno_log_every", 10) == 0:
            log(
                f"  [irno] ep {epoch:4d}/{cfg['irno_epochs']} loss={hist['train_loss'][-1]:.4e} val_mse(K steps)={val_mse:.4e}"
            )
    if best_state is not None:
        phi.load_state_dict(best_state)
    info = dict(
        best_val_mse=float(best_val),
        epochs_run=len(hist["epoch"]),
        seconds=time.perf_counter() - t0,
    )
    log(
        f"  [irno] done: {info['epochs_run']} epochs, val_mse={best_val:.4e}, {info['seconds']:.1f}s"
    )
    return (phi.eval(), hist, info)


@torch.no_grad()
def irno_predict(base, phi, X, D, K, alpha, device, batch_size=16):
    base, phi = (base.to(device).eval(), phi.to(device).eval())
    Xt = np.ascontiguousarray(X.transpose(0, 3, 1, 2), np.float32)
    Dt = np.ascontiguousarray(D.transpose(0, 3, 1, 2), np.float32)
    out = []
    for i in range(0, len(Xt), batch_size):
        xb = torch.from_numpy(Xt[i : i + batch_size]).to(device)
        db = torch.from_numpy(Dt[i : i + batch_size]).to(device)
        h0 = base(xb, db, None).float()
        if h0.dim() == 3:
            h0 = h0.unsqueeze(1)
        x_phi = xb[:, :1]
        hK = rollout(phi, x_phi, h0, K, alpha)
        out.append(hK.squeeze(1).cpu().numpy())
    return np.concatenate(out, axis=0)
