import numpy as np
import torch

GND_PARTNER = {"fp_12": "fp_11", "fp_11": "fp_12", "fp_22": "fp_21", "fp_21": "fp_22"}
MODELED_COMPONENTS = ("fp_11", "fp_22", "fp_12")


def _pgrad_np(f, axis):
    return (np.roll(f, -1, axis=axis) - np.roll(f, 1, axis=axis)) / 2.0


def _pgrad_torch(f, dim):
    return (torch.roll(f, -1, dims=dim) - torch.roll(f, 1, dims=dim)) / 2.0


def alpha13_np(Fp12, Fp11, axes=(-2, -1)):
    return _pgrad_np(Fp12, axes[0]) - _pgrad_np(Fp11, axes[1])


def alpha23_np(Fp22, Fp21, axes=(-2, -1)):
    return _pgrad_np(Fp22, axes[0]) - _pgrad_np(Fp21, axes[1])


def alpha13_torch(Fp12, Fp11, dims=(-2, -1)):
    return _pgrad_torch(Fp12, dims[0]) - _pgrad_torch(Fp11, dims[1])


def alpha23_torch(Fp22, Fp21, dims=(-2, -1)):
    return _pgrad_torch(Fp22, dims[0]) - _pgrad_torch(Fp21, dims[1])


def gnd_field_np(comp_name, own, partner, axes=(-2, -1)):
    if comp_name == "fp_12":
        return alpha13_np(own, partner, axes)
    if comp_name == "fp_11":
        return alpha13_np(partner, own, axes)
    if comp_name == "fp_22":
        return alpha23_np(own, partner, axes)
    if comp_name == "fp_21":
        return alpha23_np(partner, own, axes)
    raise ValueError(f"no GND term defined for component {comp_name!r}")


def gnd_field_torch(comp_name, own, partner, dims=(-2, -1)):
    if comp_name == "fp_12":
        return alpha13_torch(own, partner, dims)
    if comp_name == "fp_11":
        return alpha13_torch(partner, own, dims)
    if comp_name == "fp_22":
        return alpha23_torch(own, partner, dims)
    if comp_name == "fp_21":
        return alpha23_torch(partner, own, dims)
    raise ValueError(f"no GND term defined for component {comp_name!r}")


def gnd_consistency_loss_torch(comp_name, own_pred, own_true, partner_true, dims=(-2, -1)):
    pred_field = gnd_field_torch(comp_name, own_pred, partner_true, dims)
    true_field = gnd_field_torch(comp_name, own_true, partner_true, dims)
    return torch.mean((pred_field - true_field) ** 2)


GND_AXIS = {"fp_12": -2, "fp_11": -1, "fp_22": -2, "fp_21": -1}


def gnd_directional_term_torch(comp_name, pred, y, dims=(-2, -1)):
    axis = dims[0] if GND_AXIS[comp_name] == -2 else dims[1]
    d = _pgrad_torch(pred - y, axis)
    return torch.mean(d**2)


def gnd_report_from_predictions(comp_fields):
    out = {}
    for term, (c1, c2), fn in (
        ("alpha13", ("fp_12", "fp_11"), alpha13_np),
        ("alpha23", ("fp_22", "fp_21"), alpha23_np),
    ):
        if c1 not in comp_fields or c2 not in comp_fields:
            continue
        own_true = np.asarray(comp_fields[c1]["true"])
        own_pred = np.asarray(comp_fields[c1].get("pred", own_true))
        partner_true = np.asarray(comp_fields[c2]["true"])
        partner_pred_raw = comp_fields[c2].get("pred")
        if partner_pred_raw is None:
            partner_pred, partner_source = (partner_true, "ground_truth")
        else:
            partner_pred, partner_source = (np.asarray(partner_pred_raw), "model")
        field_true = fn(own_true, partner_true)
        field_pred = fn(own_pred, partner_pred)
        err = field_pred - field_true
        sst = float((field_true**2).sum())
        r2 = float(1 - (err**2).sum() / sst) if sst > 0 else float("nan")
        out[term] = dict(
            components=[c1, c2],
            partner_source=partner_source,
            rmse=float(np.sqrt((err**2).mean())),
            rms_true=float(np.sqrt((field_true**2).mean())),
            r2=r2,
            mean_abs_true=float(np.abs(field_true).mean()),
            mean_abs_pred=float(np.abs(field_pred).mean()),
        )
    return out
