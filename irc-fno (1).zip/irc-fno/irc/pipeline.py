import json
import os
import time

import numpy as np
import pandas as pd
import torch

from .data import AUG_GROUPS
from .metrics import full_report, global_metrics
from .model import build_model, count_params, forward_flops
from .spectral import band_energy_fractions, frequency_mask, select_modes
from .train import FieldDataset, predict, train_model
from .uq import calibrate_and_evaluate

DEFAULTS = dict(
    modes1=16,
    modes2=12,
    width=32,
    n_layers=4,
    descriptor_dim=16,
    dropout=0.1,
    use_global_skip=True,
    epochs=500,
    lr=0.0001,
    batch_size=8,
    weight_decay=0.001,
    clip_grad_norm=1.0,
    T_0=50,
    T_mult=2,
    eta_min=1e-06,
    ema_decay=0.999,
    swa_start_frac=0.8,
    swa_lr=1e-05,
    use_amp=True,
    log_every=20,
    early_stop_patience=100,
    early_stop_min_epochs=60,
    data_loss="mse",
    max_iter=10,
    res_epochs=None,
    res_width=24,
    res_n_layers=3,
    res_dropout=0.15,
    res_weight_decay=0.005,
    res_mode_policy="psd",
    res_coverage=0.8,
    res_modes_fixed=[32, 26],
    res_modes_cap=None,
    min_modes=4,
    res_lambda_spec=0.1,
    res_state_input=False,
    warmstart_residual=True,
    crossfit_folds=5,
    alpha_policy="oof_ls",
    alpha_init=0.5,
    alpha_anneal=0.9,
    alpha_max=1.0,
    accept_rel_tol=0.0,
    tol_r2=0.001,
    stall_patience=3,
    res_r2_floor=0.01,
    res_r2_patience=2,
    augment="none",
    descriptor_version="v2",
    sigma_curv_list=[0.8, 1.2, 2.0],
    periodic=True,
    n_states=2,
    mc_samples=30,
    conformal_coverage=0.95,
    gnd_lambda=0.0,
)
COMPONENT_OVERRIDES = {
    "fp_11": {},
    "fp_22": {},
    "fp_12": dict(
        modes1=20,
        modes2=16,
        width=48,
        max_iter=15,
        epochs=600,
        tol_r2=0.002,
        res_width=48,
        res_n_layers=4,
        res_modes_cap=32,
    ),
}


def partial_load(model, state):
    own = model.state_dict()
    n = 0
    for k, v in state.items():
        if k in own and own[k].shape == v.shape:
            own[k].copy_(v)
            n += 1
    model.load_state_dict(own)
    return (n, len(own))


def kfold_positions(n, K, seed):
    rng = np.random.default_rng(seed)
    return np.array_split(rng.permutation(n), K)


def r2(y, p):
    sst = ((y - y.mean()) ** 2).sum()
    return float(1 - ((y - p) ** 2).sum() / sst) if sst > 0 else float("nan")


class Ctx:

    def __init__(
        self,
        X,
        D,
        fp_all,
        split,
        out_dir,
        device,
        desc_perms=None,
        strata=None,
        periodic=True,
        log=print,
    ):
        self.X, self.D, self.fp, self.split = (X, D, fp_all, split)
        self.out_dir, self.device, self.perms = (out_dir, device, desc_perms or {})
        self.strata, self.periodic, self.log = (strata, periodic, log)
        self.H, self.W = X.shape[1:3]
        self.in_ch, self.desc_ch = (X.shape[-1], D.shape[-1])

    def take(self, name, arr):
        return arr[self.split[name]]


def _arch_base(cfg, ctx):
    return dict(
        modes1=cfg["modes1"],
        modes2=cfg["modes2"],
        width=cfg["width"],
        n_layers=cfg["n_layers"],
        in_channels=ctx.in_ch,
        desc_channels=ctx.desc_ch,
        descriptor_dim=cfg["descriptor_dim"],
        dropout=cfg["dropout"],
        state_channels=0,
        use_global_skip=cfg["use_global_skip"],
    )


def _arch_res(cfg, ctx, m1, m2):
    return dict(
        modes1=m1,
        modes2=m2,
        width=cfg["res_width"],
        n_layers=cfg["res_n_layers"],
        in_channels=ctx.in_ch,
        desc_channels=ctx.desc_ch,
        descriptor_dim=cfg["descriptor_dim"],
        dropout=cfg["res_dropout"],
        state_channels=1 if cfg["res_state_input"] else 0,
        use_global_skip=True,
    )


def _fit(
    ctx,
    cfg,
    comp,
    arch,
    Xa,
    Da,
    ya,
    Xv,
    Dv,
    yv,
    *,
    epochs,
    wd,
    tag,
    seed,
    sa=None,
    sv=None,
    y_off=0.0,
    s_off=0.0,
    fmask=None,
    lam=0.0,
    init=None,
):
    model = build_model(arch)
    if init is not None:
        n, t = partial_load(model, init)
        ctx.log(f"  [{tag}] warm-start: {n}/{t} tensors")
    aug = cfg["augment"] != "none"
    ops = AUG_GROUPS[cfg["augment"]]
    tr = FieldDataset(Xa, Da, ya, comp, sa, y_off, s_off, ops, ctx.perms, augment=aug)
    va = FieldDataset(Xv, Dv, yv, comp, sv, y_off, s_off, augment=False)
    gnd_lambda = cfg.get("gnd_lambda", 0.0)
    gnd_comp = comp if gnd_lambda > 0 and comp in ("fp_11", "fp_22", "fp_12") else None
    model, hist, info = train_model(
        model,
        tr,
        va,
        cfg,
        epochs=epochs,
        weight_decay=wd,
        tag=tag,
        device=ctx.device,
        seed=seed,
        freq_mask=fmask,
        lambda_spec=lam,
        data_loss=cfg["data_loss"],
        log=ctx.log,
        gnd_lambda=gnd_lambda,
        gnd_comp=gnd_comp,
    )
    info["train_flops"] = forward_flops(model, ctx.H, ctx.W) * 3 * len(Xa) * info["epochs_run"]
    return (model, hist, info)


def _save_ckpt(path, model, extra):
    torch.save({"state_dict": model.state_dict(), "arch": model.arch, **extra}, path)


def load_pipeline(manifest_path, device="cpu"):
    with open(manifest_path) as f:
        man = json.load(f)
    root = os.path.dirname(manifest_path)

    def load(entry):
        ck = torch.load(os.path.join(root, entry["path"]), map_location=device, weights_only=False)
        m = build_model(ck["arch"])
        m.load_state_dict(ck["state_dict"])
        return m.to(device).eval()

    base = load(man["base"])
    corrs = [(load(c), c) for c in man["correctors"]]
    return (man, base, corrs)


def pipeline_predict(man, base, corrs, X, D, batch_size=16, mc=False, device=None, upto=None):
    mu, sg = (man["y_mean"], man["y_std"])
    Y = predict(base, X, D, None, batch_size, device, mc) * sg + mu
    for model, c in corrs[:upto]:
        st = (Y - mu) / sg if man["state_input"] else None
        Y = Y + c["alpha"] * (
            predict(model, X, D, st, batch_size, device, mc) * c["r_std"] + c["r_mean"]
        )
    return Y


def run_component(comp, rc, ctx, cfg, seed=0, mode="irc"):
    log, dev = (ctx.log, ctx.device)
    cdir = os.path.join(ctx.out_dir, f"{comp}_seed{seed}")
    for sub in ("checkpoints", "arrays", "figures"):
        os.makedirs(os.path.join(cdir, sub), exist_ok=True)
    with open(os.path.join(cdir, "config.json"), "w") as f:
        json.dump({**cfg, "component": comp, "seed": seed, "mode": mode}, f, indent=2)
    t_start = time.perf_counter()
    y_all = ctx.fp[:, :, :, rc[0], rc[1]].astype(np.float32)
    S = {n: ctx.split[n] for n in ("train", "val", "calib", "test")}
    Xs = {n: ctx.X[i] for n, i in S.items()}
    Ds = {n: ctx.D[i] for n, i in S.items()}
    ys = {n: y_all[i] for n, i in S.items()}
    phases_te = Xs["test"][..., 0] > 0.5
    strata_te = None if ctx.strata is None else ctx.strata[S["test"]]
    mu, sg = (float(ys["train"].mean()), float(ys["train"].std()) + 1e-12)
    z = lambda a: (a - mu) / sg
    log(
        f"\n{'=' * 72}\n  {comp}  seed={seed}  mode={mode}  train={len(S['train'])} val={len(S['val'])} calib={len(S['calib'])} test={len(S['test'])}\n{'=' * 72}"
    )
    K = int(cfg["crossfit_folds"]) if mode == "irc" else 0
    folds = kfold_positions(len(S["train"]), K, seed + 17) if K > 0 else []
    train_flops, accepted, hist_rows = (0.0, [], [])
    arch_b = _arch_base(cfg, ctx)
    base, bh, binfo = _fit(
        ctx,
        cfg,
        comp,
        arch_b,
        Xs["train"],
        Ds["train"],
        z(ys["train"]),
        Xs["val"],
        Ds["val"],
        z(ys["val"]),
        epochs=cfg["epochs"],
        wd=cfg["weight_decay"],
        tag="base",
        seed=seed,
        y_off=mu / sg,
    )
    train_flops += binfo["train_flops"]
    pd.DataFrame(bh).to_csv(os.path.join(cdir, "base_training_curve.csv"), index=False)
    _save_ckpt(os.path.join(cdir, "checkpoints", "base.pt"), base, {"y_mean": mu, "y_std": sg})
    P = lambda m, n, st=None: predict(m, Xs[n], Ds[n], st, cfg["batch_size"], dev)
    Y = {n: P(base, n) * sg + mu for n in ("val", "calib", "test")}
    Y_base_test = Y["test"].copy()
    if K > 0:
        Ytr = np.empty_like(ys["train"])
        fold_states = []
        for f, pos in enumerate(folds):
            keep = np.setdiff1d(np.arange(len(S["train"])), pos)
            m, _, inf = _fit(
                ctx,
                cfg,
                comp,
                arch_b,
                Xs["train"][keep],
                Ds["train"][keep],
                z(ys["train"][keep]),
                Xs["val"],
                Ds["val"],
                z(ys["val"]),
                epochs=cfg["epochs"],
                wd=cfg["weight_decay"],
                tag=f"base_f{f}",
                seed=seed + 101 * (f + 1),
                y_off=mu / sg,
            )
            train_flops += inf["train_flops"]
            Ytr[pos] = (
                predict(m, Xs["train"][pos], Ds["train"][pos], None, cfg["batch_size"], dev) * sg
                + mu
            )
            fold_states.append(None)
        Y["train"] = Ytr
    else:
        Y["train"] = P(base, "train") * sg + mu
        fold_states = []

    def row(k, stage, **kw):
        vm = global_metrics(ys["val"], Y["val"], comp)
        tm = global_metrics(ys["test"], Y["test"], comp)
        hist_rows.append(
            dict(
                iteration=k,
                stage=stage,
                val_R2=vm["R2"],
                val_RMSE=vm["RMSE"],
                val_MSE=vm["MSE"],
                test_R2=tm["R2"],
                test_RMSE=tm["RMSE"],
                train_residual_rms=float(np.sqrt(((ys["train"] - Y["train"]) ** 2).mean())),
                **kw,
            )
        )

    row(
        0,
        "base",
        accepted=True,
        base_val_mse_z=binfo["best_val_mse"],
        train_residual_source="out_of_fold" if K > 0 else "in_sample",
    )
    log(
        f"  base: val R2={hist_rows[-1]['val_R2']:.4f}  (train residual rms {hist_rows[-1]['train_residual_rms']:.3e}, {('OOF' if K > 0 else 'in-sample')})"
    )
    max_iter = cfg["max_iter"] if mode == "irc" else 0
    res_epochs = cfg["res_epochs"] or cfg["epochs"]
    prev_full_state = None
    stall = rr2 = 0
    stop_reason = "max_iter reached" if max_iter else "base only"
    for k in range(1, max_iter + 1):
        r_tr, r_va = (ys["train"] - Y["train"], ys["val"] - Y["val"])
        rmu, rsg = (float(r_tr.mean()), float(r_tr.std()) + 1e-12)
        zr = lambda a: (a - rmu) / rsg
        rz_tr, rz_va = (zr(r_tr), zr(r_va))
        if cfg["res_mode_policy"] == "psd":
            cap = None if cfg["res_modes_cap"] is None else (cfg["res_modes_cap"],) * 2
            sel = select_modes(rz_tr, cfg["res_coverage"], cfg["min_modes"], cap)
            m1, m2 = (sel["m1"], sel["m2"])
        else:
            m1 = min(int(cfg["res_modes_fixed"][0]), ctx.H // 2)
            m2 = min(int(cfg["res_modes_fixed"][1]), ctx.W // 2 + 1)
            sel = dict(m1=m1, m2=m2, captured=float("nan"), reachable=True)
        bands = band_energy_fractions(rz_tr)
        fmask = frequency_mask(rz_tr) if cfg["res_lambda_spec"] > 0 else None
        st = (lambda n: z(Y[n])) if cfg["res_state_input"] else lambda n: None
        log(
            f"\n  ── iter {k}: modes used ({m1},{m2}) captured={sel['captured']:.3f} | residual band energy low/mid/high = {bands[0]:.2f}/{bands[1]:.2f}/{bands[2]:.2f}"
        )
        arch_r = _arch_res(cfg, ctx, m1, m2)
        init = prev_full_state if cfg["warmstart_residual"] else None
        corr, rh, rinfo = _fit(
            ctx,
            cfg,
            comp,
            arch_r,
            Xs["train"],
            Ds["train"],
            rz_tr,
            Xs["val"],
            Ds["val"],
            rz_va,
            epochs=res_epochs,
            wd=cfg["res_weight_decay"],
            tag=f"res{k}",
            seed=seed + 1000 * k,
            sa=st("train"),
            sv=st("val"),
            y_off=rmu / rsg,
            s_off=mu / sg,
            fmask=fmask,
            lam=cfg["res_lambda_spec"],
            init=init,
        )
        train_flops += rinfo["train_flops"]
        pd.DataFrame(rh).to_csv(os.path.join(cdir, f"res{k}_training_curve.csv"), index=False)
        C = {n: P(corr, n, st(n)) * rsg + rmu for n in ("val", "calib", "test")}
        corr_val_r2 = r2(r_va, C["val"])
        new_fold_states = []
        if K > 0:
            c_tr = np.empty_like(r_tr)
            for f, pos in enumerate(folds):
                keep = np.setdiff1d(np.arange(len(S["train"])), pos)
                sa = None if st("train") is None else st("train")[keep]
                m, _, inf = _fit(
                    ctx,
                    cfg,
                    comp,
                    arch_r,
                    Xs["train"][keep],
                    Ds["train"][keep],
                    rz_tr[keep],
                    Xs["val"],
                    Ds["val"],
                    rz_va,
                    epochs=res_epochs,
                    wd=cfg["res_weight_decay"],
                    tag=f"res{k}_f{f}",
                    seed=seed + 1000 * k + 101 * (f + 1),
                    sa=sa,
                    sv=st("val"),
                    y_off=rmu / rsg,
                    s_off=mu / sg,
                    fmask=fmask,
                    lam=cfg["res_lambda_spec"],
                    init=fold_states[f] if cfg["warmstart_residual"] else None,
                )
                train_flops += inf["train_flops"]
                sp = None if st("train") is None else st("train")[pos]
                c_tr[pos] = (
                    predict(m, Xs["train"][pos], Ds["train"][pos], sp, cfg["batch_size"], dev) * rsg
                    + rmu
                )
                new_fold_states.append(
                    {kk: v.detach().cpu().clone() for kk, v in m.state_dict().items()}
                )
        else:
            c_tr = P(corr, "train", st("train")) * rsg + rmu
        if cfg["alpha_policy"] == "oof_ls" and K > 0:
            alpha = float(np.sum(r_tr * c_tr) / max(np.sum(c_tr**2), 1e-300))
        elif cfg["alpha_policy"] in ("val_ls", "oof_ls"):
            alpha = float(np.sum(r_va * C["val"]) / max(np.sum(C["val"] ** 2), 1e-300))
        else:
            alpha = cfg["alpha_init"] * cfg["alpha_anneal"] ** k
        alpha = float(np.clip(alpha, 0.0, cfg["alpha_max"]))
        mse_old = float(np.mean((ys["val"] - Y["val"]) ** 2))
        Yv_new = Y["val"] + alpha * C["val"]
        mse_new = float(np.mean((ys["val"] - Yv_new) ** 2))
        frac_imp = float((np.abs(ys["val"] - Yv_new) < np.abs(r_va)).mean())
        accept = alpha > 0 and mse_new < mse_old * (1 - cfg["accept_rel_tol"])
        prev_r2 = hist_rows[-1]["val_R2"]
        if accept:
            for n in ("val", "calib", "test"):
                Y[n] = Y[n] + alpha * C[n]
            Y["train"] = Y["train"] + alpha * c_tr
            name = f"corrector_{len(accepted) + 1:02d}.pt"
            _save_ckpt(
                os.path.join(cdir, "checkpoints", name),
                corr,
                {"alpha": alpha, "r_mean": rmu, "r_std": rsg, "iteration": k},
            )
            p = count_params(corr, ctx.H, ctx.W)
            accepted.append(
                dict(
                    path=os.path.join("checkpoints", name),
                    alpha=alpha,
                    r_mean=rmu,
                    r_std=rsg,
                    iteration=k,
                    modes=[m1, m2],
                    params_effective=p["effective"],
                    inference_flops=forward_flops(corr, ctx.H, ctx.W),
                )
            )
            prev_full_state = {kk: v.detach().cpu().clone() for kk, v in corr.state_dict().items()}
            if K > 0:
                fold_states = new_fold_states
        row(
            k,
            f"corrector_{k}",
            accepted=accept,
            alpha=alpha,
            modes_used=f"{m1}x{m2}",
            spectrum_captured=sel["captured"],
            band_low=bands[0],
            band_mid=bands[1],
            band_high=bands[2],
            corrector_val_R2=corr_val_r2,
            val_mse_candidate=mse_new,
            frac_pixels_improved=frac_imp,
            corrector_epochs=rinfo["epochs_run"],
            corrector_selected=rinfo["selected"],
        )
        log(
            f"  iter {k}: alpha={alpha:.3f} corrector val R2={corr_val_r2:.4f} val MSE {mse_old:.4e} -> {mse_new:.4e} {('ACCEPTED' if accept else 'REJECTED')} | pipeline val R2={hist_rows[-1]['val_R2']:.4f}"
        )
        pd.DataFrame(hist_rows).to_csv(os.path.join(cdir, "history.csv"), index=False)
        d_r2 = hist_rows[-1]["val_R2"] - prev_r2
        stall = stall + 1 if d_r2 < cfg["tol_r2"] else 0
        rr2 = rr2 + 1 if corr_val_r2 < cfg["res_r2_floor"] else 0
        if stall >= cfg["stall_patience"]:
            stop_reason = f"val dR2 < {cfg['tol_r2']} for {stall} iterations"
            break
        if rr2 >= cfg["res_r2_patience"]:
            stop_reason = f"corrector val R2 < {cfg['res_r2_floor']} for {rr2} iterations"
            break
    log(f"  stop: {stop_reason}; accepted correctors: {len(accepted)}")
    man = dict(
        component=comp,
        row_col=list(rc),
        y_mean=mu,
        y_std=sg,
        state_input=bool(cfg["res_state_input"]),
        base=dict(path=os.path.join("checkpoints", "base.pt")),
        correctors=accepted,
        grid=[ctx.H, ctx.W],
        descriptor=dict(
            version=cfg["descriptor_version"],
            sigma_curv_list=cfg["sigma_curv_list"],
            periodic=cfg["periodic"],
            n_states=cfg["n_states"],
            scaler="../descriptor_scaler.npz",
        ),
    )
    man_path = os.path.join(cdir, "manifest.json")
    with open(man_path, "w") as f:
        json.dump(man, f, indent=2)
    man_l, base_l, corrs_l = load_pipeline(man_path, dev)
    Yc = pipeline_predict(
        man_l, base_l, corrs_l, Xs["calib"], Ds["calib"], cfg["batch_size"], device=dev
    )
    Yt = pipeline_predict(
        man_l, base_l, corrs_l, Xs["test"], Ds["test"], cfg["batch_size"], device=dev
    )
    reload_err = float(max(np.abs(Yt - Y["test"]).max(), np.abs(Yc - Y["calib"]).max()))
    sd_c = sd_t = None
    if cfg["mc_samples"] and cfg["mc_samples"] > 1:

        def mc_std(n):
            draws = np.stack(
                [
                    pipeline_predict(
                        man_l, base_l, corrs_l, Xs[n], Ds[n], cfg["batch_size"], mc=True, device=dev
                    )
                    for _ in range(cfg["mc_samples"])
                ]
            )
            return draws.std(0)

        torch.manual_seed(seed + 7)
        sd_c, sd_t = (mc_std("calib"), mc_std("test"))
    conf = calibrate_and_evaluate(
        ys["calib"], Y["calib"], sd_c, ys["test"], Y["test"], sd_t, cfg["conformal_coverage"]
    )
    p_base = count_params(base_l, ctx.H, ctx.W)
    acct = dict(
        params_base_effective=p_base["effective"],
        params_total_effective=p_base["effective"] + sum((c["params_effective"] for c in accepted)),
        inference_flops_per_sample=forward_flops(base_l, ctx.H, ctx.W)
        + sum((c["inference_flops"] for c in accepted)),
        n_forward_passes=1 + len(accepted),
        training_flops_total=train_flops,
        wall_seconds_total=time.perf_counter() - t_start,
        crossfit_folds=K,
    )
    report = dict(
        component=comp,
        seed=seed,
        mode=mode,
        stop_reason=stop_reason,
        n_accepted=len(accepted),
        alphas=[c["alpha"] for c in accepted],
        modes=[c["modes"] for c in accepted],
        accounting=acct,
        manifest_reload_max_abs_diff=reload_err,
        test_base=full_report(ys["test"], Y_base_test, comp, phases_te, strata_te, ctx.periodic),
        test_final=full_report(ys["test"], Y["test"], comp, phases_te, strata_te, ctx.periodic),
        conformal=conf,
    )
    with open(os.path.join(cdir, "test_report.json"), "w") as f:
        json.dump(report, f, indent=2)
    np.savez_compressed(
        os.path.join(cdir, "arrays", "test_predictions.npz"),
        test_idx=S["test"],
        y_true=ys["test"],
        y_base=Y_base_test,
        y_final=Y["test"],
        mc_std=sd_t if sd_t is not None else np.zeros(0),
    )
    pd.DataFrame(hist_rows).to_csv(os.path.join(cdir, "history.csv"), index=False)
    _plots(
        cdir,
        comp,
        hist_rows,
        ys["test"],
        Y_base_test,
        Y["test"],
        Xs["test"],
        report["test_final"].get("interface_profile"),
        report["test_base"].get("interface_profile"),
    )
    tb, tf = (report["test_base"], report["test_final"])
    log(
        f"  TEST  base R2={tb['R2']:.4f} RMSE={tb['RMSE']:.3e}  ->  final R2={tf['R2']:.4f} RMSE={tf['RMSE']:.3e} | params {acct['params_total_effective'] / 1000000.0:.2f}M (base {acct['params_base_effective'] / 1000000.0:.2f}M) | reload diff {reload_err:.1e}"
    )
    return dict(
        component=comp,
        seed=seed,
        mode=mode,
        n_accepted=len(accepted),
        stop_reason=stop_reason,
        test_R2_base=tb["R2"],
        test_R2_final=tf["R2"],
        test_RMSE_base=tb["RMSE"],
        test_RMSE_final=tf["RMSE"],
        test_relL2inc_final=tf["relL2_increment"],
        params_total_M=acct["params_total_effective"] / 1000000.0,
        inference_GFLOPs=acct["inference_flops_per_sample"] / 1000000000.0,
        training_PFLOPs=acct["training_flops_total"] / 1000000000000000.0,
        wall_hours=acct["wall_seconds_total"] / 3600,
        field_coverage=conf["fieldwise"]["test_field_coverage"],
    )


def _plots(cdir, comp, hist_rows, yt, yb, yf, X, prof_f, prof_b):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fd = os.path.join(cdir, "figures")
    h = pd.DataFrame(hist_rows)
    acc = h[h["accepted"].astype(bool)]
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(acc["iteration"], acc["val_R2"], "o-", label="val (selection)")
    ax.plot(acc["iteration"], acc["test_R2"], "s--", label="test (reporting only)")
    ax.set_xlabel("accepted stage (0 = base)")
    ax.set_ylabel("R$^2$")
    ax.legend()
    ax.grid(alpha=0.3)
    ax.set_title(comp)
    fig.savefig(os.path.join(fd, "r2_vs_stage.png"), dpi=130, bbox_inches="tight")
    plt.close(fig)
    for i in range(min(3, len(yt))):
        fig, axs = plt.subplots(1, 5, figsize=(20, 3.8))
        lo, hi = (yt[i].min(), yt[i].max())
        for a, img, t in zip(
            axs,
            [X[i, ..., 0], yt[i], yf[i], np.abs(yt[i] - yb[i]), np.abs(yt[i] - yf[i])],
            ["microstructure", "truth", "final", "|err| base", "|err| final"],
        ):
            kw = dict(vmin=lo, vmax=hi) if t in ("truth", "final") else {}
            if t.startswith("|err|"):
                kw = dict(vmin=0, vmax=np.abs(yt[i] - yb[i]).max())
            im = a.imshow(
                img,
                origin="lower",
                cmap=(
                    "binary" if t == "microstructure" else "hot_r" if t.startswith("|") else "turbo"
                ),
                **kw,
            )
            a.set_title(t)
            a.axis("off")
            plt.colorbar(im, ax=a, fraction=0.046)
        fig.savefig(os.path.join(fd, f"test_sample{i}.png"), dpi=110, bbox_inches="tight")
        plt.close(fig)
    if prof_f:
        fig, ax = plt.subplots(figsize=(6, 4))
        lab = [f"({r['lo']:g},{r['hi']:g}]" for r in prof_f]
        ax.plot(range(len(lab)), [r["rmse"] for r in prof_b], "o-", label="base")
        ax.plot(range(len(lab)), [r["rmse"] for r in prof_f], "s-", label="final")
        ax.set_xticks(range(len(lab)))
        ax.set_xticklabels(lab, rotation=45)
        ax.set_xlabel("signed distance to phase boundary [px] (<0: phase 0)")
        ax.set_ylabel("test RMSE")
        ax.legend()
        ax.grid(alpha=0.3)
        fig.savefig(
            os.path.join(fd, "error_vs_interface_distance.png"), dpi=130, bbox_inches="tight"
        )
        plt.close(fig)
