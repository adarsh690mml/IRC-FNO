from __future__ import annotations

import hashlib
import json
import os
import time

import numpy as np
from scipy.ndimage import distance_transform_edt, gaussian_filter

COMPONENTS = {"fp_11": (0, 0), "fp_22": (1, 1), "fp_12": (0, 1)}
COMP_LABELS = {"fp_11": "$F^p_{11}$", "fp_22": "$F^p_{22}$", "fp_12": "$F^p_{12}$"}


def normalize_microstructure(X):
    X = np.asarray(X, dtype=np.float32).copy()
    if X.ndim == 4:
        for c in range(X.shape[-1]):
            mx = X[..., c].max()
            if mx > 0:
                X[..., c] /= mx
    else:
        if X.max() > 1.0:
            X = (X - X.min()) / (X.max() - X.min() + 1e-12)
        X = X[..., None]
    return X


def data_convention_report(fp_all, n_max=200, seed=0):
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(fp_all), size=min(n_max, len(fp_all)), replace=False)
    F = np.asarray(fp_all[idx], dtype=np.float64)
    det3 = np.linalg.det(F.reshape(-1, 3, 3))
    det2 = F[..., 0, 0] * F[..., 1, 1] - F[..., 0, 1] * F[..., 1, 0]
    rep = {
        "n_samples_checked": int(len(idx)),
        "abs_det3_minus_1_max": float(np.abs(det3 - 1).max()),
        "abs_det3_minus_1_mean": float(np.abs(det3 - 1).mean()),
        "abs_det2_minus_1_max": float(np.abs(det2 - 1).max()),
        "abs_det2_minus_1_mean": float(np.abs(det2 - 1).mean()),
        "abs_fp33_minus_1_max": float(np.abs(F[..., 2, 2] - 1).max()),
        "abs_fp13_max": float(np.abs(F[..., 0, 2]).max()),
        "abs_fp23_max": float(np.abs(F[..., 1, 2]).max()),
        "abs_fp12_max": float(np.abs(F[..., 0, 1]).max()),
        "abs_fp12_minus_fp21_max": float(np.abs(F[..., 0, 1] - F[..., 1, 0]).max()),
        "rms_fp12_minus_fp21_over_rms_fp12": float(
            np.sqrt(np.mean((F[..., 0, 1] - F[..., 1, 0]) ** 2))
            / (np.sqrt(np.mean(F[..., 0, 1] ** 2)) + 1e-300)
        ),
    }
    for name, (r, c) in COMPONENTS.items():
        v = F[..., r, c]
        rep[f"{name}_min"], rep[f"{name}_max"] = (float(v.min()), float(v.max()))
        rep[f"{name}_std"] = float(v.std())
    rep["interpretation"] = (
        "2D det(Fp)=1 is only valid if |Fp33-1|, |Fp13|, |Fp23| are ~0. Fp12=Fp21 is only valid if rms(Fp12-Fp21)/rms(Fp12) is ~0. Neither physics loss is used by default in v2."
    )
    return rep


SPLIT_NAMES = ("train", "val", "calib", "test")


def make_splits(N, fracs=(0.7, 0.1, 0.1, 0.1), seed=0, groups=None, strata=None):
    fracs = np.asarray(fracs, dtype=float)
    if len(fracs) != 4 or np.any(fracs < 0) or (not np.isclose(fracs.sum(), 1.0)):
        raise ValueError(f"fracs must be 4 non-negative numbers summing to 1, got {fracs}")
    groups = np.arange(N) if groups is None else np.asarray(groups)
    strata = np.zeros(N, dtype=int) if strata is None else np.asarray(strata)
    if len(groups) != N or len(strata) != N:
        raise ValueError("groups/strata must have length N")
    uniq = np.unique(groups)
    g_stratum = {}
    for g in uniq:
        s = np.unique(strata[groups == g])
        if len(s) != 1:
            raise ValueError(f"group {g} spans several strata {s}")
        g_stratum[g] = s[0]
    rng = np.random.default_rng(seed)
    assign = {}
    for s in np.unique(strata):
        gs = np.array([g for g in uniq if g_stratum[g] == s])
        gs = gs[rng.permutation(len(gs))]
        cuts = np.round(np.cumsum(fracs) * len(gs)).astype(int)
        cuts[-1] = len(gs)
        start = 0
        for name, stop in zip(SPLIT_NAMES, cuts):
            for g in gs[start:stop]:
                assign[g] = name
            start = stop
    out = {
        name: np.sort(np.where(np.array([assign[g] == name for g in groups]))[0])
        for name in SPLIT_NAMES
    }
    return out


def save_split(path, split, meta):
    if os.path.exists(path):
        raise FileExistsError(f"{path} exists; refusing to overwrite a split file")
    with open(path, "w") as f:
        json.dump({"meta": meta, **{k: v.tolist() for k, v in split.items()}}, f)


def load_split(path, N):
    with open(path) as f:
        d = json.load(f)
    split = {k: np.asarray(d[k], dtype=int) for k in SPLIT_NAMES}
    allidx = np.concatenate(list(split.values()))
    if len(np.unique(allidx)) != len(allidx):
        raise ValueError("split file has overlapping indices")
    if allidx.max() >= N:
        raise ValueError(f"split file references index {allidx.max()} >= N={N}")
    return (split, d.get("meta", {}))


def strata_from_blocks(N, n_blocks):
    if N % n_blocks:
        raise ValueError(f"N={N} not divisible by n_blocks={n_blocks}")
    return np.arange(N) // (N // n_blocks)


DEFAULT_MATERIAL_MODELS = ("Isotropic", "Linear", "Power Law")
DEFAULT_MORPHOLOGIES = ("Bicontinuous", "Elongated", "Inclusion", "Random")


def load_plasticity_material(root, material_model, morphologies=DEFAULT_MORPHOLOGIES):
    mdir = os.path.join(root, material_model)
    if not os.path.isdir(mdir):
        raise FileNotFoundError(
            f"material-model folder not found: {mdir!r} (looked under root={root!r})"
        )
    Xs, Fs, labels, names = ([], [], [], [])
    for i, morph in enumerate(morphologies):
        mpath = os.path.join(mdir, morph)
        if not os.path.isdir(mpath):
            raise FileNotFoundError(f"morphology folder not found: {mpath!r}")
        key = morph.lower()
        fp_path = os.path.join(mpath, f"Fp_{key}.npy")
        x_path = os.path.join(mpath, f"input_phase_{key}.npy")
        if not os.path.exists(fp_path):
            raise FileNotFoundError(fp_path)
        if not os.path.exists(x_path):
            raise FileNotFoundError(x_path)
        fp = np.load(fp_path)
        x = np.load(x_path)
        if len(fp) != len(x):
            raise ValueError(f"{mpath}: Fp has {len(fp)} samples, input_phase has {len(x)}")
        Xs.append(x)
        Fs.append(fp)
        labels.append(np.full(len(x), i, dtype=int))
        names.append(morph)
    X_raw = np.concatenate(Xs, axis=0)
    fp_all = np.concatenate(Fs, axis=0)
    morph_labels = np.concatenate(labels, axis=0)
    return (X_raw, fp_all, morph_labels, names)


def discover_material_models(root, candidates=DEFAULT_MATERIAL_MODELS):
    found = [m for m in candidates if os.path.isdir(os.path.join(root, m))]
    if not found:
        raise FileNotFoundError(
            f"none of {list(candidates)} found as subfolders of {root!r}; actual subfolders: {sorted(os.listdir(root))}"
        )
    return found


def _primitive_basis(X, n_states=2):
    domain = [0, 1]
    H = np.linspace(domain[0], domain[1], n_states + 1)
    X_ = np.maximum(1 - np.abs(X[..., None] - H) / (H[1] - H[0]), 0)
    return X_[..., list(range(n_states))]


def curvature_field(phase, sigma=1.2, periodic=True):
    phase = np.asarray(phase, dtype=np.uint8)
    if periodic:
        Ny, Nx = phase.shape
        tiled = np.tile(phase, (3, 3))
        d_in = distance_transform_edt(tiled == 1)[Ny : 2 * Ny, Nx : 2 * Nx]
        d_out = distance_transform_edt(tiled == 0)[Ny : 2 * Ny, Nx : 2 * Nx]
    else:
        d_in = distance_transform_edt(phase == 1)
        d_out = distance_transform_edt(phase == 0)
    phi = d_out - d_in
    mode = "wrap" if periodic else "nearest"
    phi = gaussian_filter(phi.astype(float), sigma=sigma, mode=mode)
    phi_y, phi_x = np.gradient(phi)
    phi_yy, _ = np.gradient(phi_y)
    phi_xy, phi_xx = np.gradient(phi_x)
    grad2 = phi_x**2 + phi_y**2
    kappa = (phi_xx * phi_y**2 - 2.0 * phi_x * phi_y * phi_xy + phi_yy * phi_x**2) / (
        grad2**1.5 + 1e-08
    )
    return (kappa.astype(np.float32), phi.astype(np.float32))


def curvature_field_batch(phases, sigma=1.2, periodic=True):
    N, Ny, Nx = phases.shape
    kappas = np.empty((N, Ny, Nx), dtype=np.float32)
    phis = np.empty((N, Ny, Nx), dtype=np.float32)
    for i in range(N):
        kappas[i], phis[i] = curvature_field(phases[i], sigma=sigma, periodic=periodic)
    return (kappas, phis)


def generate2ndOrder(X_):
    if X_.ndim != 4:
        raise ValueError(f"generate2ndOrder expects (N,Nx,Ny,h), got {X_.shape}")
    samples, Nx, Ny, h = X_.shape
    d, sigma = (15, 10)
    result = np.zeros((samples, Nx, Ny, 10), dtype=np.float32)
    X1 = X_[..., 0]
    X2 = X_[..., 1] if h > 1 else np.zeros_like(X1)
    for dx in range(-d, d + 1):
        for dy in range(-d, d + 1):
            if dx == 0 and dy == 0:
                continue
            w = np.exp(-(dx**2 + dy**2) / (2 * sigma**2))
            u1 = np.roll(X1, shift=(dx, dy), axis=(1, 2))
            u2 = np.roll(X2, shift=(dx, dy), axis=(1, 2))
            use_h1 = X1 != 0
            v = np.where(use_h1, X1, X2)
            u = np.where(use_h1, u1, u2)
            contrib = w * v * u
            result[..., 0] += contrib
            if dy == 0 and dx > 0:
                result[..., 1] += contrib
            elif dy == 0 and dx < 0:
                result[..., 2] += contrib
            elif dx == 0 and dy > 0:
                result[..., 3] += contrib
            elif dx == 0 and dy < 0:
                result[..., 4] += contrib
            elif dx == dy and dx > 0:
                result[..., 5] += contrib
            elif dx == dy and dx < 0:
                result[..., 6] += contrib
            elif dx == -dy and dx > 0:
                result[..., 7] += contrib
            elif dx == -dy and dx < 0:
                result[..., 8] += contrib
            result[..., 9] += w * (X1 * u2 + X2 * u1)
    return result


def descriptor_n_channels(in_channels, n_states=2, n_sigmas=3, l_load=0):
    return n_states * in_channels + 10 + n_sigmas * in_channels + l_load


def _primitive_basis_v2(X, n_states=2):
    H = np.linspace(0.0, 1.0, n_states)
    return np.maximum(1 - np.abs(X[..., None] - H) / (H[1] - H[0]), 0).astype(np.float32)


def _pgrad(f):
    return ((np.roll(f, -1, 0) - np.roll(f, 1, 0)) / 2, (np.roll(f, -1, 1) - np.roll(f, 1, 1)) / 2)


def curvature_field_v2(phase, sigma=1.2, periodic=True):
    if not periodic:
        return curvature_field(phase, sigma, periodic)
    phase = np.asarray(phase, dtype=np.uint8)
    Ny, Nx = phase.shape
    tiled = np.tile(phase, (3, 3))
    d_in = distance_transform_edt(tiled == 1)[Ny : 2 * Ny, Nx : 2 * Nx]
    d_out = distance_transform_edt(tiled == 0)[Ny : 2 * Ny, Nx : 2 * Nx]
    phi = gaussian_filter((d_out - d_in).astype(float), sigma=sigma, mode="wrap")
    phi_y, phi_x = _pgrad(phi)
    phi_yy, _ = _pgrad(phi_y)
    phi_xy, phi_xx = _pgrad(phi_x)
    grad2 = phi_x**2 + phi_y**2
    kappa = (phi_xx * phi_y**2 - 2.0 * phi_x * phi_y * phi_xy + phi_yy * phi_x**2) / (
        grad2**1.5 + 1e-08
    )
    return (kappa.astype(np.float32), phi.astype(np.float32))


def build_descriptor_array(
    X, sigma_curv_list=(0.8, 1.2, 2.0), periodic=True, n_states=2, load_steps=None, version="v2"
):
    if version not in ("v1", "v2"):
        raise ValueError(version)
    basis = _primitive_basis if version == "v1" else _primitive_basis_v2
    curv = curvature_field if version == "v1" else curvature_field_v2
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 3:
        X = X[..., None]
    N, Nx, Ny, C = X.shape
    parts = []
    for c in range(C):
        parts.append(basis(X[..., c], n_states=n_states))
    parts.append(generate2ndOrder(parts[0]))
    for c in range(C):
        phase_c = (X[..., c] > 0.5).astype(np.uint8)
        X_curv_c = 1 - phase_c
        for sigma in sigma_curv_list:
            kappa = np.empty((N, Nx, Ny), np.float32)
            phi = np.empty((N, Nx, Ny), np.float32)
            for i in range(N):
                kappa[i], phi[i] = curv(X_curv_c[i], sigma=sigma, periodic=periodic)
            kf = np.where(np.abs(phi) <= 2.0, kappa, 0.0).astype(np.float32)
            parts.append(kf[..., None])
    if load_steps is not None:
        load_steps = np.asarray(load_steps, dtype=np.float32)
        L = load_steps.shape[1]
        parts.append(np.broadcast_to(load_steps[:, None, None, :], (N, Nx, Ny, L)).copy())
    desc = np.concatenate(parts, axis=-1)
    if not np.isfinite(desc).all():
        n_bad = int((~np.isfinite(desc)).sum())
        print(f"  [WARNING] {n_bad} non-finite descriptor values -- set to 0")
        desc = np.nan_to_num(desc, nan=0.0, posinf=0.0, neginf=0.0)
    return desc


def descriptor_cache_key(X, sigma_curv_list, periodic, n_states, load_steps, version):
    h = hashlib.sha1()
    h.update(np.ascontiguousarray(X, dtype=np.float32).tobytes())
    h.update(
        json.dumps(
            [
                list(map(float, sigma_curv_list)),
                bool(periodic),
                int(n_states),
                list(X.shape),
                version,
            ]
        ).encode()
    )
    if load_steps is not None:
        h.update(np.ascontiguousarray(load_steps, dtype=np.float32).tobytes())
    return h.hexdigest()[:16]


def get_descriptors(
    X,
    cache_dir,
    sigma_curv_list=(0.8, 1.2, 2.0),
    periodic=True,
    n_states=2,
    load_steps=None,
    version="v2",
):
    key = descriptor_cache_key(X, sigma_curv_list, periodic, n_states, load_steps, version)
    path = os.path.join(cache_dir, f"descriptors_{version}_{key}.npy")
    if os.path.exists(path):
        print(f"  loaded cached descriptors {path}")
        return (np.load(path), None)
    t0 = time.perf_counter()
    desc = build_descriptor_array(X, sigma_curv_list, periodic, n_states, load_steps, version)
    dt = (time.perf_counter() - t0) / len(X)
    os.makedirs(cache_dir, exist_ok=True)
    np.save(path, desc)
    print(f"  built descriptors {desc.shape} ({dt * 1000.0:.1f} ms/sample) -> {path}")
    return (desc, dt)


class ChannelScaler:

    def __init__(self, mean=None, std=None):
        self.mean, self.std = (mean, std)

    def fit(self, A):
        A = np.asarray(A, dtype=np.float64)
        self.mean = A.mean(axis=(0, 1, 2)).astype(np.float32)
        s = A.std(axis=(0, 1, 2))
        self.std = np.where(s > 1e-12, s, 1.0).astype(np.float32)
        return self

    def transform(self, A):
        return ((A - self.mean) / self.std).astype(np.float32)

    def state(self):
        return {"mean": self.mean, "std": self.std}


AUG_GROUPS = {"none": ("id",), "uniaxial_x": ("id", "flip_h", "flip_w", "rot180")}
OFFDIAG_SIGN = {"id": 1.0, "flip_h": -1.0, "flip_w": -1.0, "rot180": 1.0}


def component_sign(op, comp_name):
    return OFFDIAG_SIGN[op] if comp_name == "fp_12" else 1.0


def spatial_op(a, op, axes, lib=np):
    if op == "id":
        return a
    if lib is np:
        if op == "flip_h":
            return np.flip(a, axis=axes[0])
        if op == "flip_w":
            return np.flip(a, axis=axes[1])
        if op == "rot180":
            return np.flip(a, axis=axes)
    else:
        if op == "flip_h":
            return lib.flip(a, dims=[axes[0]])
        if op == "flip_w":
            return lib.flip(a, dims=[axes[1]])
        if op == "rot180":
            return lib.flip(a, dims=list(axes))
    raise ValueError(op)


def derive_descriptor_perms(
    ops,
    in_channels,
    sigma_curv_list,
    periodic,
    n_states,
    n_load=0,
    size=24,
    seed=0,
    tol=0.0001,
    version="v2",
):
    rng = np.random.default_rng(seed)
    f = gaussian_filter(
        rng.standard_normal((1, size, size, in_channels)), (0, 2, 2, 0), mode="wrap"
    )
    Xp = (f > np.median(f)).astype(np.float32)
    load = np.zeros((1, n_load), np.float32) + 0.5 if n_load else None
    D = build_descriptor_array(Xp, sigma_curv_list, periodic, n_states, load, version)
    perms = {}
    for op in ops:
        Dt = build_descriptor_array(
            np.ascontiguousarray(spatial_op(Xp, op, (1, 2))),
            sigma_curv_list,
            periodic,
            n_states,
            load,
            version,
        )
        Do = spatial_op(D, op, (1, 2))
        F = D.shape[-1]
        p = np.empty(F, dtype=int)
        for j in range(F):
            err = np.array([np.abs(Dt[..., j] - Do[..., i]).max() for i in range(F)])
            thr = tol * max(np.abs(Dt[..., j]).max(), 1.0)
            cands = np.where(err <= thr)[0]
            if len(cands) == 0:
                raise RuntimeError(
                    f"descriptor channel {j} is not equivariant under {op} (best match error {err.min():.3e}); augmentation unsafe"
                )
            p[j] = j if j in cands else int(cands[0])
        perms[op] = p
    return perms


def dead_channels(desc, idx=None, tol=0.0):
    A = desc if idx is None else desc[idx]
    return [int(c) for c in range(A.shape[-1]) if np.ptp(A[..., c]) <= tol]
