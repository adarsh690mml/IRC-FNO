import copy
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset

from . import physics
from .data import component_sign, spatial_op


class FieldDataset(Dataset):

    def __init__(
        self,
        X,
        D,
        y,
        comp_name,
        state=None,
        y_offset=0.0,
        state_offset=0.0,
        ops=("id",),
        desc_perms=None,
        augment=False,
    ):
        self.x = torch.from_numpy(np.ascontiguousarray(X.transpose(0, 3, 1, 2), np.float32))
        self.d = torch.from_numpy(np.ascontiguousarray(D.transpose(0, 3, 1, 2), np.float32))
        self.y = torch.from_numpy(np.ascontiguousarray(y, np.float32))
        self.s = (
            None
            if state is None
            else torch.from_numpy(np.ascontiguousarray(state, np.float32)).unsqueeze(1)
        )
        self.comp = comp_name
        self.y_off, self.s_off = (float(y_offset), float(state_offset))
        self.ops = list(ops) if augment else ["id"]
        self.perms = {op: torch.as_tensor(p) for op, p in (desc_perms or {}).items()}
        for op in self.ops:
            if op != "id" and op not in self.perms:
                raise ValueError(f"no descriptor permutation for op {op}")

    def __len__(self):
        return self.x.shape[0]

    def __getitem__(self, i):
        x, d, y = (self.x[i], self.d[i], self.y[i])
        s = self.s[i] if self.s is not None else torch.zeros(0)
        op = self.ops[int(torch.randint(len(self.ops), (1,)))] if len(self.ops) > 1 else self.ops[0]
        if op != "id":
            x = spatial_op(x, op, (-2, -1), torch)
            d = spatial_op(d, op, (-2, -1), torch)[self.perms[op]]
            sg = component_sign(op, self.comp)
            y = sg * spatial_op(y, op, (-2, -1), torch) + (sg - 1) * self.y_off
            if self.s is not None:
                s = sg * spatial_op(s, op, (-2, -1), torch) + (sg - 1) * self.s_off
        return (x, d, y, s)


class EMA:

    def __init__(self, model, decay=0.999):
        self.decay = decay
        self.model = copy.deepcopy(model).eval()
        for p in self.model.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        for e, p in zip(self.model.parameters(), model.parameters()):
            e.mul_(self.decay).add_(p.detach(), alpha=1 - self.decay)
        for e, b in zip(self.model.buffers(), model.buffers()):
            e.copy_(b)


def data_term(pred, y, kind):
    err = (pred - y) ** 2
    if kind == "mse":
        return err.mean()
    if kind == "rel_mse":
        var = y.var(dim=(-2, -1), keepdim=True) + 1e-12
        return (err / var).mean()
    raise ValueError(kind)


def spectral_term(pred, y, mask):
    E = torch.fft.rfft2(pred - y, norm="ortho")
    return (E.abs() ** 2 * mask).sum(dim=(-2, -1)).mean()


def _forward(model, xb, db, sb):
    return model(xb, db, sb if sb.numel() else None)


@torch.no_grad()
def evaluate_mse(model, loader, device):
    model.eval()
    se, n = (0.0, 0)
    for xb, db, yb, sb in loader:
        p = _forward(model, xb.to(device), db.to(device), sb.to(device)).float()
        se += ((p - yb.to(device)) ** 2).sum().item()
        n += yb.numel()
    return se / max(n, 1)


def train_model(
    model,
    train_set,
    val_set,
    cfg,
    *,
    epochs,
    weight_decay,
    tag,
    device,
    seed=0,
    freq_mask=None,
    lambda_spec=0.0,
    data_loss="mse",
    log=print,
    gnd_lambda=0.0,
    gnd_comp=None,
):
    torch.manual_seed(seed)
    model = model.to(device)
    g = torch.Generator().manual_seed(seed)
    tl = DataLoader(train_set, batch_size=cfg["batch_size"], shuffle=True, generator=g)
    vl = DataLoader(val_set, batch_size=cfg["batch_size"], shuffle=False)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"], weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
        opt, T_0=cfg["T_0"], T_mult=cfg["T_mult"], eta_min=cfg["eta_min"]
    )
    ema = EMA(model, cfg["ema_decay"])
    swa = torch.optim.swa_utils.AveragedModel(model)
    swa_sched = torch.optim.swa_utils.SWALR(opt, swa_lr=cfg["swa_lr"])
    swa_start = int(cfg["swa_start_frac"] * epochs)
    swa_used = False
    use_amp = bool(cfg["use_amp"] and device.type == "cuda")
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    fm = None if freq_mask is None else torch.as_tensor(freq_mask, device=device)
    hist = {k: [] for k in ("epoch", "train_loss", "train_data", "val_mse", "lr", "grad_norm")}
    best_val, best_state, since_best, retried = (np.inf, None, 0, False)
    t0 = time.perf_counter()
    epoch = 1
    while epoch <= epochs:
        model.train()
        tot, dat, gn, nb, bad = (0.0, 0.0, 0.0, 0, False)
        for xb, db, yb, sb in tl:
            xb, db, yb, sb = (xb.to(device), db.to(device), yb.to(device), sb.to(device))
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=use_amp):
                pred = _forward(model, xb, db, sb)
            pred = pred.float()
            ld = data_term(pred, yb, data_loss)
            loss = ld + (
                lambda_spec * spectral_term(pred, yb, fm)
                if lambda_spec > 0 and fm is not None
                else 0.0
            )
            if gnd_lambda > 0 and gnd_comp is not None:
                loss = loss + gnd_lambda * physics.gnd_directional_term_torch(gnd_comp, pred, yb)
            if not torch.isfinite(loss):
                bad = True
                break
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            norm = nn.utils.clip_grad_norm_(
                model.parameters(), cfg["clip_grad_norm"] or float("inf")
            )
            scaler.step(opt)
            scaler.update()
            ema.update(model)
            tot += loss.item()
            dat += ld.item()
            gn += float(norm)
            nb += 1
        if bad:
            log(f"  [{tag}] non-finite loss at epoch {epoch}: halving LR, reloading best state")
            for pg in opt.param_groups:
                pg["lr"] *= 0.5
            if best_state is not None:
                model.load_state_dict(best_state)
                ema = EMA(model, cfg["ema_decay"])
            if retried:
                log(f"  [{tag}] non-finite loss persisted -- stopping this stage")
                break
            retried = True
            continue
        retried = False
        val = evaluate_mse(ema.model, vl, device)
        hist["epoch"].append(epoch)
        hist["train_loss"].append(tot / max(nb, 1))
        hist["train_data"].append(dat / max(nb, 1))
        hist["val_mse"].append(val)
        hist["lr"].append(opt.param_groups[0]["lr"])
        hist["grad_norm"].append(gn / max(nb, 1))
        if val < best_val:
            best_val, since_best = (val, 0)
            best_state = {k: v.detach().cpu().clone() for k, v in ema.model.state_dict().items()}
        else:
            since_best += 1
        if epoch >= swa_start:
            swa.update_parameters(model)
            swa_sched.step()
            swa_used = True
        else:
            sched.step()
        if epoch == 1 or epoch % cfg["log_every"] == 0:
            log(
                f"  [{tag}] ep {epoch:4d}/{epochs} loss={hist['train_loss'][-1]:.4e} data={hist['train_data'][-1]:.4e} val_mse={val:.4e} lr={hist['lr'][-1]:.2e} |g|={hist['grad_norm'][-1]:.2e}"
            )
        pat = cfg.get("early_stop_patience")
        if (
            pat
            and epoch >= cfg.get("early_stop_min_epochs", 0)
            and (epoch < swa_start)
            and (since_best >= pat)
        ):
            log(f"  [{tag}] early stop at epoch {epoch} (best val_mse={best_val:.4e})")
            break
        epoch += 1
    final = copy.deepcopy(model)
    if best_state is not None:
        final.load_state_dict(best_state)
    selected = "ema"
    if swa_used:
        swa_val = evaluate_mse(swa.module, vl, device)
        if swa_val < best_val:
            final = copy.deepcopy(swa.module)
            best_val, selected = (swa_val, "swa")
    info = dict(
        best_val_mse=float(best_val),
        epochs_run=len(hist["epoch"]),
        selected=selected,
        seconds=time.perf_counter() - t0,
    )
    log(
        f"  [{tag}] done: {info['epochs_run']} epochs, {selected} selected, val_mse={best_val:.4e}, {info['seconds']:.1f}s"
    )
    return (final.eval(), hist, info)


@torch.no_grad()
def predict(model, X, D, state=None, batch_size=16, device=None, mc=False):
    device = device or next(model.parameters()).device
    model.eval()
    if mc:
        for m in model.modules():
            if isinstance(m, (nn.Dropout, nn.Dropout2d)):
                m.train()
    Xt = np.ascontiguousarray(X.transpose(0, 3, 1, 2), np.float32)
    Dt = np.ascontiguousarray(D.transpose(0, 3, 1, 2), np.float32)
    out = []
    for i in range(0, len(Xt), batch_size):
        xb = torch.from_numpy(Xt[i : i + batch_size]).to(device)
        db = torch.from_numpy(Dt[i : i + batch_size]).to(device)
        sb = (
            None
            if state is None
            else torch.from_numpy(np.ascontiguousarray(state[i : i + batch_size], np.float32))
            .unsqueeze(1)
            .to(device)
        )
        out.append(model(xb, db, sb).float().cpu().numpy())
    model.eval()
    return np.concatenate(out, axis=0)
