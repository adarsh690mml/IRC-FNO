# IRC-FNO

Fourier Neural Operator with Iterative Residual Correction for predicting plastic deformation fields (Fp11, Fp22, Fp12) from two-phase microstructures.

A base FNO with gated descriptor injection makes a first prediction. Each correction stage trains a new FNO on the remaining residual and adds a scaled copy of its output:

```
Y_0 = Base(X, D)
Y_{k+1} = Y_k + alpha_k * C_k(X, D)
```

Residual targets are computed out-of-fold, each stage's Fourier mode budget is chosen from the residual spectrum, `alpha_k` is fitted by least squares, and a stage is kept only if validation error decreases.

## Repository structure

```
irc-fno/
├── irc/                     core package
│   ├── data.py              data loading, splits, descriptors, scaling, augmentation
│   ├── spectral.py          residual spectrum analysis and Fourier mode selection
│   ├── model.py             DescriptorFNO, spectral convolution, parameter and FLOP counts
│   ├── train.py             dataset and training loop (EMA, SWA, warm restarts, early stopping)
│   ├── pipeline.py          base model, correction loop, manifest and test report
│   ├── metrics.py           global, frequency-band, hotspot, interface and per-class metrics
│   ├── uq.py                MC-dropout and split-conformal uncertainty
│   ├── physics.py           Nye-tensor (GND) consistency check and optional loss
│   └── irno.py              Iterative Refinement Neural Operator baseline
├── scripts/
│   ├── run_irc.py           train and evaluate IRC-FNO
│   ├── analyze_results.py   per-stage accuracy gain against parameters and FLOPs
│   ├── run_ablations.py     ablation suite for one material model and component
│   ├── run_irno.py          train and evaluate the IRNO baseline
│   └── compare_irno.py      IRC-FNO vs IRNO comparison
├── tests/                   pytest suite
├── docs/
│   ├── CHANGES.md           design decisions and fixes relative to the original implementation
│   ├── EXPERIMENTS.md       experiment plan
│   └── OUTPUTS.md           description of every output file
├── requirements.txt
└── pyproject.toml
```

## Installation

```bash
git clone <repository-url>
cd irc-fno
pip install -r requirements.txt
python -m pytest -q tests
```

Python 3.9 or later and PyTorch 2.0 or later are required. A CUDA GPU is used automatically when available.

## Data layout

```
PLASTICITY DATA/
├── Isotropic/
│   ├── Bicontinuous/
│   │   ├── Fp_bicontinuous.npy          (N, H, W, 3, 3)
│   │   └── input_phase_bicontinuous.npy (N, H, W) or (N, H, W, C)
│   ├── Elongated/
│   ├── Inclusion/
│   └── Random/
├── Linear/
└── Power Law/
```

Each material model is trained separately. Its four morphology files are concatenated and the morphology label is used to stratify the train/val/calib/test split (70/10/10/10).

## Usage

```bash
ROOT="/path/to/PLASTICITY DATA"

python scripts/run_irc.py --smoke --out runs/smoke

python scripts/run_irc.py --plasticity-root "$ROOT" --out runs/all_models --seeds 0 1 2

python scripts/run_irc.py --plasticity-root "$ROOT" --material-models Isotropic \
    --components fp_12 --seeds 0 --out runs/iso_fp12

python scripts/analyze_results.py --run-dir runs/all_models

python scripts/run_ablations.py --plasticity-root "$ROOT" --material-models Isotropic \
    --components fp_12 --seeds 0 --out runs/ablations_iso_fp12

python scripts/run_irno.py --plasticity-root "$ROOT" --material-models Isotropic --component fp_12 \
    --irc-run-dir runs/all_models/Isotropic --out runs/irno_iso_fp12 --K 4 --eval-K 4 8
python scripts/compare_irno.py --irc-run-dir runs/all_models/Isotropic --component fp_12 \
    --irno-run-dir runs/irno_iso_fp12
```

Configuration values can be overridden with `--set KEY=VALUE`, for example `--set crossfit_folds=3 stall_patience=1`. Each `--out` directory must be new.

A capacity-matched single FNO baseline is trained with `--mode base`, setting `--modes`, `--width` (or `--target-params`) and `--epochs`.

## Outputs

```
runs/all_models/
├── summary_all.csv
├── summary_all_over_seeds.csv
├── log.txt
└── <MaterialModel>/
    ├── split.json
    ├── data_report.json
    ├── descriptor_scaler.npz
    ├── gnd_report_seed<s>.json
    ├── summary.csv
    └── <component>_seed<s>/
        ├── manifest.json
        ├── test_report.json
        ├── history.csv
        ├── checkpoints/
        └── figures/
```

`docs/OUTPUTS.md` explains each file. A trained predictor can be rebuilt from `manifest.json` with `irc.pipeline.load_pipeline`.

## Tests

```bash
python -m pytest -q tests
```

The suite covers the spectral mode selection, descriptor equivariance, split integrity, conformal coverage, physics checks, and end-to-end smoke runs of every script.
