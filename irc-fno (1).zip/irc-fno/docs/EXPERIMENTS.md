# What to run, in what order, and what each run decides

All runs on one material model see the same split (one shared `--split-file` in the legacy
layout, or a deterministic split from `--split-seed`/`--split-fracs` in `--plasticity-root`
mode -- see below), so every number is on identical samples. The test split is reported, never
used for selection.

```bash
cd irc-fno
python3 -m pytest -q tests                                  # all should pass
python3 scripts/run_irc.py --smoke --out runs/smoke                 # about 1 min, checks the install
```

## Data layout: `PLASTICITY DATA/<Isotropic|Linear|Power Law>/<morphology>/`

This is the expected layout (per-morphology `Fp_<morph>.npy` /
`input_phase_<morph>.npy` files, no combined file). One call runs every material model and
component, with its own structured output tree -- see the README for the exact directory layout
it writes. The steps below (E0-E8) are per material model: run them with `--plasticity-root`
and `--material-models <one model>`, one material model at a time, then repeat for the other two.

```bash
ROOT="/path/to/PLASTICITY DATA"
MODEL=Isotropic                          # repeat the whole plan for Linear and "Power Law"
```

`--split-file` only applies to the legacy combined-file layout; in `--plasticity-root` mode each
run creates its own `split.json` under `<out>/<Model>/`. That is not a problem: `make_splits` is
deterministic given `(N, fracs, seed, strata)`, and for one material model `N` and the exact
morphology labels are fixed by the files on disk -- so **E0..E8 below land on identical samples
automatically** as long as you leave `--split-seed` (default 0) and `--split-fracs` (default
70/10/10/10) at the same values for every run on that model. Don't pass `--split-file` at all
here; just give each experiment its own `--out`.

```bash
# E0: original base architecture, base only
python3 scripts/run_irc.py --plasticity-root "$ROOT" --material-models "$MODEL" \
    --out runs/$MODEL/E0_base --mode base --seeds 0 1 2
```
This re-establishes base R² on a shuffled, stratified **test** split (stratified by the exact
morphology label derived from the file layout). Expect it to differ from earlier results, which used
a validation split taken from the end of the file.

To run the full E0-E8 plan below on real data, replace every `--data-path $DATA $STRAT
--split-file $SPLIT` with `--plasticity-root "$ROOT" --material-models "$MODEL"`, and give each
experiment its own `--out runs/$MODEL/<tag>` (e.g. `E1_irc`, `E2_big`, ...). To run all three
material models in ONE call instead of one at a time (e.g. for the E0 baseline, where there is
no cross-run split to keep aligned), just omit `--material-models` (or list all three) and point
`--out` at one directory -- see the README.

Legacy single-combined-file layout is unchanged -- keep using `--data-path`/`$STRAT`/
`--split-file` for older datasets:
```bash
DATA=/path/to/combined_data/
SPLIT=runs/split.json                                       # created by the first run, then reused
STRAT="--morph-blocks 4"   # ONLY if texture_combined.npy is 4 contiguous equal classes.
                           # Prefer --morph-file labels.npy (one int per sample). If several rows
                           # belong to one microstructure, also pass --groups-file.
```

## Legacy single-combined-file layout: Step 1 — new baselines on the clean split
```bash
# E0: original base architecture, base only
python3 scripts/run_irc.py --data-path $DATA --out runs/E0_base $STRAT --split-file $SPLIT \
    --mode base --seeds 0 1 2
```
This re-establishes base R² on a shuffled, stratified **test** split. Expect it to differ from earlier results, which used a validation split taken from the end of the file.

## Step 2 — the decisive comparison
```bash
# E1: corrected IRC (out-of-fold residuals, line-search alpha, val acceptance)
python3 scripts/run_irc.py --data-path $DATA --out runs/E1_irc $STRAT --split-file $SPLIT --seeds 0 1 2

# E2: capacity-matched single FNO. Set --target-params to E1's params_total_M (summary.csv)
#     and --epochs to roughly the total epochs E1 spent (base + correctors).
python3 scripts/run_irc.py --data-path $DATA --out runs/E2_big $STRAT --split-file $SPLIT --mode base \
    --modes 32 32 --target-params <E1 total params> --epochs <matched> --seeds 0 1 2
python3 scripts/run_irc.py --data-path $DATA --out runs/E2b_big50 $STRAT --split-file $SPLIT --mode base \
    --modes 50 50 --target-params <E1 total params> --epochs <matched> --seeds 0 1 2
```
**Decision:**
* If E1 beats E2/E2b on test, by more than the seed spread, IRC is a method. Report parameters, FLOPs and wall time side by side.
* If it does not, the old gains were capacity and resolution, and the paper's story must change.

## Step 3 — ablations (one factor at a time, vs E1, same split and seeds)
| Run | Flag | Question |
|---|---|---|
| E3 | `--set crossfit_folds=0 alpha_policy="val_ls"` | How much did in-sample residuals inflate or deflate the correction? |
| E4 | `--set res_mode_policy="fixed" res_modes_fixed=[32,26]` | Does PSD selection beat a fixed budget at similar cost? |
| E5 | `--set res_state_input=true` | Does a state-dependent corrector C(X, Y_k) beat C(X)? This is the IRNO-relevant axis. |
| E6 | `--set augment="uniaxial_x"` | Does symmetry-valid augmentation help? **Only valid if** the loading is mirror-symmetric (uniaxial along x1 with traction-free sides) **and** each phase's response is invariant under reflection; confirm for your crystal-plasticity setup. |
| E7 | `--set descriptor_version="v1"` | Effect of the descriptor bug fix (and descriptors at all, vs a run with descriptors zeroed, if wanted). |
| E8 | `--set res_lambda_spec=0` | Is the frequency-weighted loss doing anything? |

**Automated:** `run_ablations.py` runs E1 and E3–E8 for one model/component and writes
`ablation_report/ablation_summary.csv` (see the README). E9 (`--set gnd_lambda=0.05`)
tests the GND-consistency loss. Judge it by `gnd_report_seed*.json` alpha13 `r2`, not only by
Fp R².

## Step 4 — IRNO baseline
`run_irno.py` (same frozen base, same split) then `compare_irno.py`. **Decision:** if IRNO matches
IRC-FNO at fewer params/FLOPs, the per-stage correctors and cross-fitting do not earn their cost.
If IRC-FNO wins by more than the seed spread at comparable FLOPs, that is evidence for the
stage-wise, validation-gated design. Also check IRNO's `extrapolation_R2_by_K`: does running more
steps than trained still help on this data?

## Compute
* With `crossfit_folds=5`, each stage trains 6 models (1 full + 5 folds). Expect roughly **6× the training time** of the original per stage.
* `--set crossfit_folds=3` gives about 4× (fold models then see 2/3 of the data, which slightly overstates residuals — conservative).
* To save time, run `--components fp_12` first: it is the hardest and most informative component.
* Inference cost is unaffected by cross-fitting; only the full-data models are deployed.

## Files to inspect
For each run directory:
* `summary.csv`, `summary_over_seeds.csv`;
* per component: `history.csv`, `test_report.json`;
* `data_report.json` (once) and `log.txt`.

`history.csv` holds the per-stage corrector R², α, modes used and accepted flag.

## Reading the outputs
* **`history.csv`:** one row per stage. `accepted`, `alpha`, `modes_used`, `corrector_val_R2`, `val_R2` (selection) and `test_R2` (reporting only).
* **`test_report.json`:** `test_base` vs `test_final` (global, band, hotspot, interface profile, per class), `accounting` (total params, inference FLOPs, forward passes, training FLOPs, wall time) and `conformal`.
* **`manifest.json`:** the deployed predictor. Rebuild it with `irc.pipeline.load_pipeline`. New inputs need descriptors built with the same version, scaled with `descriptor_scaler.npz`.
