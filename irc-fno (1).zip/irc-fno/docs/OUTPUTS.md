# What a run produces, and how to read it

This file lists every output and what question each one answers. Each item is tagged with how
useful it is for actually *understanding* the model, not just reporting a score.

## 1. `scripts/run_irc.py --plasticity-root ...` (the main sweep)

```
runs/all_models/
  summary_all.csv               one row per (material_model, component, seed)
  summary_all_over_seeds.csv    mean ± std over seeds
  log.txt                       everything, each line tagged [Model]
  Isotropic/  Linear/  Power_Law/
    data_report.json            physics checks on YOUR labels (det Fp, Fp33, Fp12 vs Fp21)
    split.json                  exact train/val/calib/test indices (stratified by morphology)
    descriptor_scaler.npz       needed to reuse any trained model on new microstructures
    gnd_report_seed<s>.json     GND / Nye-tensor consistency of the final predictions (see §3)
    summary.csv
    fp_11_seed0/  fp_22_seed0/  fp_12_seed0/
      test_report.json          the main result file (see below)
      history.csv               one row per correction stage
      manifest.json             the deployed predictor (base + accepted correctors + alphas)
      base_training_curve.csv, res<k>_training_curve.csv
      arrays/test_predictions.npz   y_true, y_base, y_final on every test sample
      checkpoints/*.pt
      figures/
        r2_vs_stage.png               val and test R² after each accepted stage
        test_sample{0,1,2}.png        microstructure | truth | prediction | |err| base | |err| final
        error_vs_interface_distance.png   error as a function of distance to the phase boundary
        contribution.png              (after analyze_results.py) R² vs cumulative FLOPs
```

### `test_report.json`: the file to open first

| Key | What it tells you | Use for understanding |
|---|---|---|
| `test_base` / `test_final` → `R2`, `RMSE`, `relL2_increment` | Headline accuracy before and after correction, on held-out test data. Errors are computed on Fp − I, so they are not inflated by the identity. | Medium: says *whether* IRC helped, not *why*. |
| `…→ band_relerr_low/mid/high` | Relative error in low/mid/high spatial-frequency bands. | **High.** If correction gains are all in the high band, IRC is fixing spectral bias, which is its claimed mechanism. If the gains are low-band, a bigger base model would probably do the same job. |
| `…→ hotspot_top1pct_mae/_rel`, `hotspot_top5pct_mae/_rel` | Error where plastic strain is largest. Also `max_abs_error`, `p99_abs_error`, `peak_increment_rel_error`. | **High.** Localization bands are where the physics matters. A model can have a good R² and still miss them. |
| `…→ interface_profile` | RMSE binned by signed distance to the phase boundary. | **High.** Shows whether errors concentrate at interfaces, where descriptors (curvature, 2-point stats) are supposed to help. |
| `…→ per_class` | Metrics per morphology, keyed `"0"`–`"3"` = Bicontinuous, Elongated, Inclusion, Random (the `--morphologies` order). | **High.** Tells you which microstructures the model struggles with, and whether IRC helps some morphologies and not others. |
| `accounting` | Total params, inference FLOPs/sample, forward passes, training FLOPs, wall time, all for the whole deployed pipeline. | Needed for any fair comparison against a bigger single FNO or IRNO. |
| `conformal` → `fieldwise` | Calibrated uncertainty band with a valid coverage guarantee. | Medium: tells you how far to trust a prediction on a new sample. |
| `manifest_reload_max_abs_diff` | Should be about 1e-7. Confirms the saved model reproduces the reported numbers. | Sanity check only. |

### `history.csv`: how the correction loop behaved
One row per stage: `accepted`, `alpha`, `modes_used`, `corrector_val_R2`, `band_low/mid/high`
(the residual's spectral content *before* that stage), `val_R2`, `test_R2`.

**Use it to understand the method**:
* Watch `band_high` fall from stage to stage. That is direct evidence that the correctors are
  removing high-frequency residual.
* Small or shrinking `alpha` with low `corrector_val_R2` means the stages are running out of
  learnable signal.
* Rejected stages (`accepted=False`) are the validation gate doing its job.

## 2. `scripts/analyze_results.py --run-dir runs/all_models`: contribution and FLOPs

* `contribution_summary.csv`, plus `contribution.csv` per component run: one row per stage with
  `test_R2`, `test_R2_gain` (what that stage added), `params_added`, `inference_flops_added` and
  the cumulative totals.
* `base_vs_final_summary.csv`: base R², final R², R² gained by IRC, final params and GFLOPs, for
  every model × component × seed.
* `figures/contribution.png`: R² by stage, and R² against cumulative inference FLOPs.

**Use:** this shows where accuracy is bought and at what compute price. If stage 1 gives most of
the gain and stages 2–5 add FLOPs for little R², a shorter pipeline is the better trade.

## 3. GND / Nye-tensor consistency

`gnd_report_seed<s>.json` (written automatically when fp_11 and fp_12, and/or fp_22, were run).

**Why this check and not curl(Fp) = 0.** Saint-Venant compatibility is a property of the
*total* deformation (F = ∇y must be curl-free). Fp alone is generally *incompatible*: its curl is
Nye's dislocation-density tensor, i.e. the geometrically necessary dislocations. Forcing
curl(Fp) → 0 would make predictions less physical, not more. The meaningful check is whether
the predicted Fp has the **same** curl as the true Fp. For this planar dataset (Fp13 = Fp23 = 0
in `data_report.json`):

* `alpha13 = ∂Fp12/∂x1 − ∂Fp11/∂x2`, built from the fp_12 **and** fp_11 model predictions. This is
  a real cross-model check (`partner_source: "model"`).
* `alpha23 = ∂Fp22/∂x1 − ∂Fp21/∂x2`. Fp21 is not modeled, so its ground truth is used
  (`partner_source: "ground_truth"`). This term measures only the fp_22 model's part.

Each term reports `r2` and `rmse` of the predicted GND field against the true one, plus `rms_true`
for scale. A model with a high Fp R² but a low GND R² gets the values right but the spatial
gradients wrong. That is exactly the failure a physics-consistency check should catch, because
derivatives amplify high-frequency error.

**Optional training term** `--set gnd_lambda=0.05`: adds a soft GND-consistency loss for every
stage. Mathematically, a per-component model can only hold the *other* component at its ground
truth, and that partner then cancels. The term therefore reduces to a directional-gradient
(Sobolev-type) penalty on the component's own error, along the axis that enters its GND formula.
It is a legitimate regulariser for the gradient structure that the GND report measures. It is
**not** a full cross-component constraint, which would need a jointly-trained multi-output
model. Judge it by whether `gnd_report` R² improves (ablation: run once with and once without).

## 4. `scripts/run_ablations.py`: which pipeline component matters

```
runs/ablations_iso_fp12/
  E1_irc/  E3_no_crossfit/  E4_fixed_modes/  E5_state_input/  E7_descriptor_v1/  E8_no_spectral_loss/
  ablation_report/ablation_summary.csv
```
`ablation_summary.csv` has one row per ablation: `test_R2_final`, `delta_R2_vs_baseline`, params,
GFLOPs and wall time. **Use:**
* A negative `delta_R2` means that component helps; its size says by how much.
* A delta smaller than the seed-to-seed spread (from `summary_all_over_seeds.csv`) means no
  measurable effect.

## 5. `scripts/run_irno.py` + `scripts/compare_irno.py`: IRNO baseline

`runs/<name>_irno/` contains `test_report.json` (same metrics format), `history.csv`,
`irno_refiner.pt`, `comparison.json`, `log.txt`.

`comparison.json` → `irc_vs_irno` gives base and final R²/RMSE, params, inference FLOPs and forward
passes side by side. `irno_extrapolation_R2_by_K` gives IRNO's R² when run for more steps than it
was trained for, which is the paper's headline claim; check whether it holds on this data. The
`architectural_differences` text spells out how the two methods differ.

Both methods start from the **same frozen base checkpoint**, so the comparison isolates the
refinement strategy. IRNO here is our reimplementation from the paper, run on the exact same split
and metrics. It is not their published code (see `irc/irno.py`).

## What these outputs can and cannot tell you
* **Can:** whether IRC beats an equal-compute alternative (needs the E2 capacity-matched run from
  EXPERIMENTS.md); which components matter (ablations); where errors live (bands, hotspots,
  interfaces, morphology); whether gradients are physically consistent (GND report); how it
  compares to IRNO at a known cost.
* **Cannot:** prove generalization to loading paths, strain levels or microstructure families
  absent from the data. Every number here is in-distribution over the four morphologies.
