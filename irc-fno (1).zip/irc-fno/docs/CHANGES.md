# IRC-FNO v2 — what changed and why

This document records how v2 differs from the original single-script implementation (`vanillaFNO_irc.py`), which is not included in this repository.

v2 keeps the method's structure: a base FNO with gated descriptor injection, followed by stage-wise residual correctors, `Y_{k+1} = Y_k + α_k C_k(X, D)`. It also keeps:
* the same base architecture and hyperparameters;
* the same per-component overrides;
* EMA, SWA and cosine warm restarts;
* the residual-model sizes.

The changes fix verified errors or remove sources of bias. Status labels:
* **confirmed bug** — demonstrated by a test;
* **methodological** — biases results, but the code does what it says;
* **cleanup** — removed or simplified.

## A. Bugs that affected the reported results

| # | Where (original) | Problem | Evidence | v2 fix |
|---|---|---|---|---|
| A1 | `SpectralConv2d.forward` | `m1 = min(modes1, H)`, not `H//2`. With modes1 > H/2, the positive- and negative-frequency slices overlap and the second write overwrites the first. Earlier runs used 66–77 modes on a 100-point axis, so this was **active**. | Verified against the original implementation: with modes1 ≥ H the output does not depend on `w_pos` at all. | Cap at H//2 (`effective_modes`). The modes actually used are logged. |
| A2 | `modes_from_spectrum` | Sorts power and counts the top bins (not a cutoff). Axis 1 is counted over both signs, axis 2 one-sided. The reported "66×34" is this artefact: 66/100 = 34/51. | Algebra; v2 selector gives 45×45 for white noise. | Exact energy of the FNO-representable set (`irc/spectral.py`), verified against an orthogonal projection on even and odd grids. Cheapest block reaching the coverage; near-ties broken toward balanced. |
| A3 | `FieldDataset` augmentation | 90° rotations under uniaxial loading change the boundary-value problem and swap Fp11↔Fp22. Flips did not change the sign of Fp12. Directional descriptor channels were not permuted. | `test_unpermuted_flip_corrupts_directional_channels`; tensor transformation rules. | Default `augment='none'`. Opt-in `uniaxial_x` = {id, flip_x1, flip_x2, rot180}, with the correct Fp12 sign (including the normalisation offset). Descriptor permutation is derived numerically from the descriptor code; it refuses to run if a channel isn't equivariant. |
| A4 | `_primitive_basis` / `generate2ndOrder` | Basis grid `[0, 0.5, 1]` truncated to `[0, 0.5]`. For binary inputs the 0.5 channel is identically zero and the phase-1 indicator never appears. The 2-point statistics therefore see one phase only, and the cross-phase channel (#9) is identically zero. **2 of 15 descriptor channels were dead.** | `test_original_descriptors_have_dead_channels_and_v2_fixes_them`. | `descriptor_version='v2'` (default) uses one indicator per state and periodic gradients in the curvature. `'v1'` reproduces the original descriptors, for ablation. |
| A5 | `physics_losses` | Substitutes ground-truth components into the 2×2 det(Fp) and Fp12 = Fp21. That is a re-weighted data loss, not physics. With σ33 = 0, Fp33 ≠ 1, so the 2×2 det = 1 targets the wrong value. Fp is not symmetric. | `test_data_convention_report_flags_invalid_physics`. `data_report.json` checks the labels directly. | Removed. A data-convention report checks det, Fp33, Fp13/23 and the asymmetry on the labels. Constraints by construction need a joint 3-component model (future work). |
| A6 | `mc_dropout_predict`, report | MC dropout sampled the base model only. Conformal intervals were centred on the MC mean, while metrics used the deterministic prediction (two different predictors). | Code trace. | MC dropout through base and every accepted corrector (propagating state). Intervals centred on the deterministic prediction. |
| A7 | `conformal_interval` | Pixel scores pooled (n = pixel count); pixels in a field are dependent, so the guarantee doesn't hold. Calibrated on half of the validation set already used for selection. | Code trace. | Dedicated calibration split. **Fieldwise** score (max over field) with a valid finite-sample guarantee over exchangeable samples. Pixelwise reported as empirical only. Coverage tested by Monte Carlo. |
| A8 | warm start | After a rollback, the next corrector was warm-started from the rejected model. | Code trace. | Warm-start from accepted correctors only. Fold models warm-start only from the same fold. |
| A9 | `extended_metrics` | Relative errors divided by \|Fp11\| ≈ 1, so peak error ≈ 0 by construction. Boundary error was a one-pixel non-periodic ring. High-uncertainty samples were dropped from band IoU. | Code trace. | Errors on Fp − I; periodic signed-distance interface profile; top-1%/5% hotspots; per-class metrics; nothing dropped. |
| A10 | `count_params`, slide totals | Reported params (3.2 M / 11.8 M) are the base model only. The deployed system has about 30× (Fp11) or about 20× (Fp12) more. | Exact match of slide numbers to base spectral weights. | Accounting of total effective parameters, inference FLOPs and forward passes for the whole deployed pipeline. Training FLOPs include fold models and rejected stages. |

## B. Methodological changes (bias removal)

| # | Original | Why it biases | v2 |
|---|---|---|---|
| B1 | `train_test_split(shuffle=False)`, train/val only | The validation set is the last 20% of the file. If classes are concatenated, it is one morphology class. No test set. | Shuffled train/val/calib/test (70/10/10/10), optionally **stratified** (`--morph-file` or `--morph-blocks`) and **grouped** (`--groups-file`). Saved and **re-used** via `--split-file` so every experiment sees identical samples. |
| B2 | Correctors trained on in-sample residuals | Residuals of a model on its own training data are smaller and differently structured than on unseen data. | `crossfit_folds=K` (default 5): out-of-fold residual targets. The full-data model of each stage is used at inference. `crossfit_folds=0` reproduces in-sample training, for the ablation. |
| B3 | Fixed α = 0.5·0.9^k | Arbitrary; wastes or overshoots the correction. | `alpha_policy='oof_ls'`: least-squares step on the out-of-fold training predictions, so no validation data is used. Options: `'val_ls'` or `'fixed'` (original). |
| B4 | Validation set used for checkpointing, rollback and stopping, *and* the reported numbers | Reported metrics are selection-biased. | Validation = selection only. **Test is used for nothing but reporting** (`test_report.json`; the per-stage test curve is reporting-only). |
| B5 | Six stop rules with tuned thresholds (entropy ratio, pixels-improved, …) | Ad hoc, partly computed on in-sample residuals. | Kept: ΔR²-stall (same `tol_r2`, patience 3), corrector-R² floor, max_iter. Entropy and pixels-improved stops removed; pixels-improved still logged. |
| B6 | Hann window on periodic fields; frequency mask normalised by its max | Window smears power and mismatches the unwindowed FFT; mask scale arbitrary. | No window. Mask normalised so that λ_spec = 0.1 means "spectral term ≈ 10% of the data term" (tested). |
| B7 | Descriptors unscaled (O(10²) channels next to [0, 1] inputs) | Poor conditioning. | Per-channel standardisation fitted on the training split only. |
| B8 | Descriptor cache `descriptors_all.npy`, no key | Silently stale if inputs or settings change. | Cache name includes a hash of the inputs, settings and version. |

## C. Cleanup
* Five loss terms reduced to one data term (`mse` or `rel_mse`) plus an optional spectral term.
* The validation metric is the same data term, so loss curves are comparable.
* Curriculum ordering removed.
* Gradient-norm and learning-rate logging.
* Seeds per model.
* `--deterministic` option.
* Outputs never overwrite (new `--out` required).
* A `manifest.json` lists exactly the accepted correctors with α and normalisation. `load_pipeline` / `pipeline_predict` rebuild the deployed predictor, and each run checks the reload matches (`manifest_reload_max_abs_diff`).

## Unchanged on purpose
* Base and residual architectures (gated blocks, InstanceNorm, global skip, dropout) and their sizes.
* Per-component overrides.
* Optimiser, schedule, EMA, SWA, early stopping.
* Microstructure normalisation.

Changing these is an experiment, not a fix.

## D. Per-material-model data layout
The data on disk (`PLASTICITY DATA/<Isotropic|Linear|Power Law>/<Bicontinuous|Elongated|
Inclusion|Random>/{Fp_<morph>.npy, input_phase_<morph>.npy}`) is not the single combined-file
layout assumed above. `irc/data.py` gained `load_plasticity_material` (loads and concatenates
one material model's four morphology files, deriving an EXACT per-sample morphology label from
which file it came from -- not the `--morph-blocks` contiguous-equal-size assumption) and
`discover_material_models`. `run_irc.py` gained `--plasticity-root`/`--material-models`/
`--morphologies`, running every requested material model x component x seed in one call and
writing a structured output tree (one `split.json`/`summary.csv` per material model, plus a
combined `summary_all.csv`); see the README. The legacy `--data-path`/`--micro-file`/`--fp-file`
layout is untouched and still the default when `--plasticity-root` is not given.

## E. Added: analysis, physics consistency, ablations, IRNO baseline
| Addition | What | Caveat |
|---|---|---|
| `analyze_results.py` | Per-stage test-R² gain with params/FLOPs added per stage (from `history.csv` + `manifest.json`), and an ablation-vs-baseline comparison table. | Synthesis only; no retraining. |
| `irc/physics.py`, `gnd_report_seed*.json` | Post-hoc GND/Nye-tensor consistency: curl of predicted Fp vs curl of true Fp (alpha13 from the fp_11 + fp_12 models; alpha23 from fp_22 + true Fp21). | Deliberately **not** curl(Fp)→0: Fp is physically incompatible wherever GNDs exist. Saint-Venant compatibility applies to total F, not Fp. |
| `gnd_lambda` (config, default 0) | Optional soft GND-consistency loss in every stage. | With a single-component model the partner must be held at ground truth and cancels; the term **is** a directional-gradient (H1-type) penalty on the component's own error. Validate with the GND report, not by assumption. |
| `scripts/run_ablations.py` | Runs E1 + E3, E4, E5, E7, E8 (E6 opt-in) and builds `ablation_summary.csv`. Resumable (skips finished subdirectories). | One model/component at a time; each ablation is a full training run. |
| `irc/irno.py`, `scripts/run_irno.py`, `scripts/compare_irno.py` | IRNO (Liu et al. 2026): frozen base + shared-weight U-Net refiner, trajectory + progressive-spectral + fixed-point losses. Trained on the same split from the same frozen base checkpoint. Reports inference FLOPs = base + K·refiner. | **Our reimplementation from the paper**, not their published code; spectral-loss normalisation is our reading of their equation. Compares methods on the same data, does not reproduce their benchmarks. |

## Tests
`python -m pytest -q tests` → **62 passed** (CPU, torch 2.15, Python 3.13, about 3 min). Mutation check: reverting each of five key fixes (mode cap, Fp12 sign, descriptor permutation, representable-set energy, conformal n+1) makes at least one test fail.

No test proves the method works on a given dataset; only training runs can show that.
