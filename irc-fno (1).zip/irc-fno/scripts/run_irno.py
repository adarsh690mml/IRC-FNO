import argparse
import json
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from irc import data as Dm
from irc import irno as Irno
from irc.metrics import full_report
from irc.model import build_model, count_params, forward_flops


def parse():
    ap = argparse.ArgumentParser(
        description="Train and evaluate the IRNO baseline on the same split and base model as an IRC-FNO run.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--out", required=True)
    ap.add_argument(
        "--irc-run-dir",
        required=True,
        help="directory containing split.json, descriptor_scaler.npz and <component>_seed<seed>/manifest.json from a completed run_irc.py run (the material-model subdirectory, e.g. runs/iso_fp12/Isotropic)",
    )
    ap.add_argument("--component", required=True, choices=list(Dm.COMPONENTS))
    ap.add_argument("--irc-seed", type=int, default=0, help="which seed of --irc-run-dir to use")
    ap.add_argument("--plasticity-root", default=None)
    ap.add_argument("--material-models", nargs="+", default=None)
    ap.add_argument("--morphologies", nargs="+", default=list(Dm.DEFAULT_MORPHOLOGIES))
    ap.add_argument("--data-path", default=None)
    ap.add_argument("--micro-file", default="texture_combined.npy")
    ap.add_argument("--fp-file", default="fp_combined.npy")
    ap.add_argument("--K", type=int, default=4, help="training horizon (refinement steps)")
    ap.add_argument(
        "--eval-K",
        type=int,
        nargs="+",
        default=None,
        help="extra K values to ALSO evaluate at test time (paper's extrapolation test, e.g. --eval-K 4 8 to check stability beyond the trained horizon)",
    )
    ap.add_argument("--alpha", type=float, default=0.5)
    ap.add_argument("--width", type=int, default=16)
    ap.add_argument("--depth", type=int, default=2)
    ap.add_argument("--epochs", type=int, default=300)
    ap.add_argument("--lr", type=float, default=0.001)
    ap.add_argument("--weight-decay", type=float, default=0.0001)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--beta-spectral", type=float, default=0.1)
    ap.add_argument("--beta-fp", type=float, default=0.1)
    ap.add_argument("--lam-start", type=float, default=0.5)
    ap.add_argument("--lam-end", type=float, default=4.0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument("--smoke", action="store_true", help="tiny synthetic data + config, for CI")
    return ap.parse_args()


def _load_data(a):
    if a.smoke:
        from run_irc import make_synthetic

        return make_synthetic()
    if a.plasticity_root:
        if not a.material_models or len(a.material_models) != 1:
            raise SystemExit(
                "--plasticity-root needs exactly ONE --material-models, the same model --irc-run-dir was trained on (its split.json indexes only that model's samples)"
            )
        X, fp, _, _ = Dm.load_plasticity_material(
            a.plasticity_root, a.material_models[0], a.morphologies
        )
        return (X, fp)
    X = np.load(os.path.join(a.data_path, a.micro_file))
    fp = np.load(os.path.join(a.data_path, a.fp_file), mmap_mode="r")
    return (X, fp)


def main():
    a = parse()
    if os.path.exists(a.out) and os.listdir(a.out):
        raise SystemExit(f"{a.out} exists and is not empty; choose a new --out")
    os.makedirs(a.out, exist_ok=True)
    logf = open(os.path.join(a.out, "log.txt"), "a")

    def log(msg=""):
        print(msg, flush=True)
        logf.write(msg + "\n")
        logf.flush()

    device = torch.device("cuda" if torch.cuda.is_available() and (not a.cpu) else "cpu")
    log(f"device={device}  torch={torch.__version__}  args={vars(a)}")
    cfg = dict(
        irno_K=a.K,
        irno_alpha=a.alpha,
        irno_lr=a.lr,
        irno_wd=a.weight_decay,
        irno_batch_size=a.batch_size,
        irno_epochs=a.epochs,
        irno_beta_spectral=a.beta_spectral,
        irno_beta_fp=a.beta_fp,
        seed=a.seed,
    )
    if a.smoke:
        cfg.update(irno_epochs=3, irno_batch_size=4)
    X_raw, fp_all = _load_data(a)
    X = Dm.normalize_microstructure(X_raw)
    N = len(X)
    comp = a.component
    rc = Dm.COMPONENTS[comp]
    y_all = fp_all[:, :, :, rc[0], rc[1]].astype(np.float32)
    split, meta = Dm.load_split(os.path.join(a.irc_run_dir, "split.json"), N)
    if meta.get("N") is not None and meta["N"] != N:
        raise SystemExit(
            f"split.json was made for N={meta['N']} samples but the loaded data has N={N}: wrong --material-models / data for this --irc-run-dir"
        )
    man_path = os.path.join(a.irc_run_dir, f"{comp}_seed{a.irc_seed}", "manifest.json")
    with open(man_path) as f:
        man = json.load(f)
    dcfg = man["descriptor"]
    D_raw = Dm.build_descriptor_array(
        X, dcfg["sigma_curv_list"], dcfg["periodic"], dcfg["n_states"], None, dcfg["version"]
    )
    scaler_npz = np.load(os.path.join(a.irc_run_dir, "descriptor_scaler.npz"))
    scaler = Dm.ChannelScaler(mean=scaler_npz["mean"], std=scaler_npz["std"])
    D = scaler.transform(D_raw)
    base_ck = torch.load(
        os.path.join(a.irc_run_dir, f"{comp}_seed{a.irc_seed}", man["base"]["path"]),
        map_location=device,
        weights_only=False,
    )
    base = build_model(base_ck["arch"]).to(device).eval()
    base.load_state_dict(base_ck["state_dict"])
    for p in base.parameters():
        p.requires_grad_(False)
    mu, sg = (man["y_mean"], man["y_std"])
    log(
        f"loaded frozen base from {a.irc_run_dir} ({comp} seed {a.irc_seed}): y_mean={mu:.4g} y_std={sg:.4g}"
    )

    def zspace(idx):
        x = torch.from_numpy(
            np.ascontiguousarray(X[idx, ..., :1].transpose(0, 3, 1, 2), np.float32)
        )
        y = torch.from_numpy(((y_all[idx] - mu) / sg).astype(np.float32)).unsqueeze(1)
        return (x, y)

    def base_h0(idx):
        Xt = np.ascontiguousarray(X[idx].transpose(0, 3, 1, 2), np.float32)
        Dt = np.ascontiguousarray(D[idx].transpose(0, 3, 1, 2), np.float32)
        out = []
        with torch.no_grad():
            for i in range(0, len(Xt), a.batch_size):
                xb = torch.from_numpy(Xt[i : i + a.batch_size]).to(device)
                db = torch.from_numpy(Dt[i : i + a.batch_size]).to(device)
                out.append(base(xb, db, None).float().cpu())
        h = torch.cat(out, 0)
        return h.unsqueeze(1) if h.dim() == 3 else h

    x_tr, y_tr = zspace(split["train"])
    h0_tr = base_h0(split["train"])
    x_va, y_va = zspace(split["val"])
    h0_va = base_h0(split["val"])
    x_te, y_te = zspace(split["test"])
    h0_te = base_h0(split["test"])
    log(f"train={len(split['train'])} val={len(split['val'])} test={len(split['test'])}")
    torch.manual_seed(a.seed)
    phi = Irno.UNetRefiner(in_channels=1, width=a.width, depth=a.depth)
    log(f"Phi_theta: {sum((p.numel() for p in phi.parameters()))} params, K={a.K} alpha={a.alpha}")
    t0 = time.perf_counter()
    phi, hist, info = Irno.train_irno(
        phi, x_tr, y_tr, h0_tr, x_va, y_va, h0_va, cfg, device, log=log
    )
    train_seconds = time.perf_counter() - t0
    import pandas as pd

    pd.DataFrame(hist).to_csv(os.path.join(a.out, "history.csv"), index=False)
    torch.save(
        {"state_dict": phi.state_dict(), "arch": dict(in_channels=1, width=a.width, depth=a.depth)},
        os.path.join(a.out, "irno_refiner.pt"),
    )
    phases_te = X[split["test"]][..., 0] > 0.5
    y_true_test = y_all[split["test"]]

    def eval_at_K(K):
        with torch.no_grad():
            hK = Irno.rollout(phi.to(device), x_te.to(device), h0_te.to(device), K, a.alpha)
        return hK.squeeze(1).cpu().numpy() * sg + mu

    y_pred_test = eval_at_K(a.K)
    y_base_test = h0_te.squeeze(1).numpy() * sg + mu
    report_final = full_report(y_true_test, y_pred_test, comp, phases_te, None, dcfg["periodic"])
    report_base = full_report(y_true_test, y_base_test, comp, phases_te, None, dcfg["periodic"])
    extrap = {}
    for K in a.eval_K or []:
        yk = eval_at_K(K)
        extrap[str(K)] = full_report(y_true_test, yk, comp, phases_te, None, dcfg["periodic"])["R2"]
    p_phi = sum((p.numel() for p in phi.parameters()))
    p_base = count_params(base, X.shape[1], X.shape[2])["effective"]
    f_base = forward_flops(base, X.shape[1], X.shape[2])
    f_phi = Irno.refiner_flops(phi, X.shape[1], X.shape[2])
    acct = dict(
        params_base_effective=p_base,
        params_total_effective=p_base + p_phi,
        params_refiner=p_phi,
        inference_flops_base=f_base,
        inference_flops_refiner_per_step=f_phi,
        inference_flops_per_sample=f_base + a.K * f_phi,
        n_forward_passes=1 + a.K,
        training_seconds_total=train_seconds,
        refinement_steps_K=a.K,
    )
    report = dict(
        method="IRNO (our reimplementation, see irc/irno.py docstring)",
        component=comp,
        K=a.K,
        alpha=a.alpha,
        accounting=acct,
        test_base=report_base,
        test_final=report_final,
        extrapolation_R2_by_K=extrap,
    )
    with open(os.path.join(a.out, "test_report.json"), "w") as f:
        json.dump(report, f, indent=2)
    log(
        f"\nIRNO TEST  h0(base) R2={report_base['R2']:.4f}  ->  K={a.K} steps R2={report_final['R2']:.4f}  Phi params={p_phi}  train_time={train_seconds:.1f}s"
    )
    if extrap:
        log("extrapolation (R2 at K beyond training horizon): " + json.dumps(extrap))
    logf.close()


if __name__ == "__main__":
    main()
