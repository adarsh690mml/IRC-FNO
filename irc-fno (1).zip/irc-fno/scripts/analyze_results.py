import argparse
import json
import os

import numpy as np
import pandas as pd


def parse():
    ap = argparse.ArgumentParser(
        description="Summarise per-stage accuracy gains, parameters and FLOPs from IRC-FNO runs.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument(
        "--run-dir",
        default=None,
        help="a run directory to build the per-stage contribution/FLOPs waterfall for (recurses for every <component>_seed<seed>/manifest.json)",
    )
    ap.add_argument(
        "--baseline",
        default=None,
        help="E1 (full pipeline) run directory for the ablation comparison",
    )
    ap.add_argument(
        "--ablation",
        nargs="*",
        default=[],
        metavar="NAME=DIR",
        help="one or more NAME=run_dir ablation runs to compare against --baseline",
    )
    ap.add_argument(
        "--out",
        default=None,
        help="where to write reports (default: --run-dir, or <baseline>_ablation_report)",
    )
    return ap.parse_args()


def find_component_dirs(run_dir):
    out = []
    for root, _, files in os.walk(run_dir):
        if "manifest.json" in files and os.path.basename(root).count("_seed"):
            out.append((os.path.relpath(root, run_dir), root))
    return sorted(out)


def stage_waterfall(cdir):
    hist = pd.read_csv(os.path.join(cdir, "history.csv"))
    with open(os.path.join(cdir, "manifest.json")) as f:
        man = json.load(f)
    with open(os.path.join(cdir, "test_report.json")) as f:
        rep = json.load(f)
    acct = rep["accounting"]
    corr_by_iter = {c["iteration"]: c for c in man["correctors"]}
    rows = []
    base_row = hist[hist["stage"] == "base"].iloc[0]
    cum_params = acct["params_base_effective"]
    base_flops = acct["inference_flops_per_sample"] - sum(
        (c["inference_flops"] for c in man["correctors"])
    )
    cum_flops = base_flops
    rows.append(
        dict(
            stage="base",
            iteration=0,
            test_R2=base_row["test_R2"],
            test_R2_gain=np.nan,
            val_R2=base_row["val_R2"],
            alpha=np.nan,
            modes_used=np.nan,
            params_added=acct["params_base_effective"],
            params_cumulative=cum_params,
            inference_flops_added=base_flops,
            inference_flops_cumulative=cum_flops,
        )
    )
    prev_test_r2 = base_row["test_R2"]
    for _, h in hist[hist["stage"] != "base"].iterrows():
        it = int(h["iteration"])
        if it not in corr_by_iter:
            continue
        c = corr_by_iter[it]
        cum_params += c["params_effective"]
        cum_flops += c["inference_flops"]
        rows.append(
            dict(
                stage=h["stage"],
                iteration=it,
                test_R2=h["test_R2"],
                test_R2_gain=h["test_R2"] - prev_test_r2,
                val_R2=h["val_R2"],
                alpha=c["alpha"],
                modes_used=h.get("modes_used", np.nan),
                params_added=c["params_effective"],
                params_cumulative=cum_params,
                inference_flops_added=c["inference_flops"],
                inference_flops_cumulative=cum_flops,
            )
        )
        prev_test_r2 = h["test_R2"]
    return (rows, rep)


def run_stage_waterfalls(run_dir, out_dir):
    all_rows = []
    for label, cdir in find_component_dirs(run_dir):
        rows, rep = stage_waterfall(cdir)
        for r in rows:
            r["run"] = label
        df = pd.DataFrame(rows)
        df.to_csv(os.path.join(cdir, "contribution.csv"), index=False)
        all_rows.extend(rows)
        try:
            _plot_waterfall(cdir, label, df)
        except Exception as e:
            print(f"  [warn] could not plot {label}: {e}")
    if not all_rows:
        print(f"no '<component>_seed<seed>/manifest.json' found under {run_dir}")
        return
    full = pd.DataFrame(all_rows)
    path = os.path.join(out_dir, "contribution_summary.csv")
    full.to_csv(path, index=False)
    print(
        f"wrote {path} ({len(find_component_dirs(run_dir))} component runs, {len(full)} stage rows)"
    )
    base_vs_final = (
        full.sort_values("iteration")
        .groupby("run")
        .agg(
            test_R2_base=("test_R2", "first"),
            test_R2_final=("test_R2", "last"),
            n_accepted_stages=("iteration", lambda s: (s > 0).sum()),
            params_final_M=("params_cumulative", lambda s: s.iloc[-1] / 1000000.0),
            inference_GFLOPs_final=(
                "inference_flops_cumulative",
                lambda s: s.iloc[-1] / 1000000000.0,
            ),
        )
    )
    base_vs_final["test_R2_gained_by_IRC"] = (
        base_vs_final["test_R2_final"] - base_vs_final["test_R2_base"]
    )
    p2 = os.path.join(out_dir, "base_vs_final_summary.csv")
    base_vs_final.to_csv(p2)
    print(f"wrote {p2}")
    print("\n" + base_vs_final.round(4).to_string())


def _plot_waterfall(cdir, label, df):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4))
    ax1.bar(df["stage"].astype(str), df["test_R2"], color="steelblue")
    ax1.set_ylabel("test R$^2$ (cumulative)")
    ax1.set_title(f"{label}: R2 by stage")
    ax1.tick_params(axis="x", rotation=45)
    ax2.plot(
        df["inference_flops_cumulative"] / 1000000000.0, df["test_R2"], "o-", color="darkorange"
    )
    ax2.set_xlabel("cumulative inference GFLOPs/sample")
    ax2.set_ylabel("test R$^2$")
    ax2.set_title("accuracy vs. compute cost")
    ax2.grid(alpha=0.3)
    fig.suptitle(label)
    fig.tight_layout()
    fig.savefig(os.path.join(cdir, "figures", "contribution.png"), dpi=130)
    plt.close(fig)


def ablation_comparison(baseline_dir, ablations, out_dir):
    base_runs = dict(find_component_dirs(baseline_dir))
    rows = []
    for name, adir in ablations.items():
        abl_runs = dict(find_component_dirs(adir))
        for label, cdir in abl_runs.items():
            with open(os.path.join(cdir, "test_report.json")) as f:
                rep = json.load(f)
            base_cdir = base_runs.get(label)
            base_rep = None
            if base_cdir:
                with open(os.path.join(base_cdir, "test_report.json")) as f:
                    base_rep = json.load(f)
            tf, tb_ = (rep["test_final"], rep["test_base"])
            row = dict(
                ablation=name,
                run=label,
                test_R2_base=tb_["R2"],
                test_R2_final=tf["R2"],
                test_RMSE_final=tf["RMSE"],
                params_total_M=rep["accounting"]["params_total_effective"] / 1000000.0,
                inference_GFLOPs=rep["accounting"]["inference_flops_per_sample"] / 1000000000.0,
                wall_hours=rep["accounting"]["wall_seconds_total"] / 3600,
            )
            if base_rep:
                bf = base_rep["test_final"]
                row["baseline_test_R2_final"] = bf["R2"]
                row["delta_R2_vs_baseline"] = tf["R2"] - bf["R2"]
                row["delta_RMSE_vs_baseline"] = tf["RMSE"] - bf["RMSE"]
            else:
                row["baseline_test_R2_final"] = row["delta_R2_vs_baseline"] = row[
                    "delta_RMSE_vs_baseline"
                ] = np.nan
            rows.append(row)
    if not rows:
        print("no matching component runs found between --baseline and --ablation dirs")
        return
    df = pd.DataFrame(rows).sort_values(["run", "ablation"])
    path = os.path.join(out_dir, "ablation_summary.csv")
    df.to_csv(path, index=False)
    print(f"wrote {path}")
    print("\n" + df.round(4).to_string(index=False))


def main():
    a = parse()
    if a.run_dir:
        out_dir = a.out or a.run_dir
        os.makedirs(out_dir, exist_ok=True)
        run_stage_waterfalls(a.run_dir, out_dir)
    if a.baseline and a.ablation:
        ablations = dict((kv.split("=", 1) for kv in a.ablation))
        out_dir = a.out or a.baseline.rstrip("/") + "_ablation_report"
        os.makedirs(out_dir, exist_ok=True)
        ablation_comparison(a.baseline, ablations, out_dir)
    if not a.run_dir and (not (a.baseline and a.ablation)):
        raise SystemExit("pass --run-dir, or --baseline together with --ablation")


if __name__ == "__main__":
    main()
