import argparse
import json
import os

ARCH_DIFFERENCES = "Architectural / training differences (IRC-FNO vs. this IRNO reimplementation):\n\n  base model            : SAME frozen checkpoint for both (the comparison isolates the\n                           refinement strategy, not the base operator)\n  refinement capacity   : IRC-FNO trains a NEW corrector network per stage (up to max_iter\n                           stages, each with its own weights) vs. IRNO's ONE shared-weight\n                           network reused for every refinement step\n  refinement inputs     : IRC-FNO's correctors see the microstructure AND the 15 hand-engineered\n                           descriptor channels (2-point correlations, curvature fields) and\n                           optionally the current state; IRNO's Phi sees only the raw\n                           microstructure and the current state (per the paper)\n  training target       : IRC-FNO trains each corrector on OUT-OF-FOLD residuals (crossfit_folds\n                           models), avoiding in-sample residual bias; IRNO trains with one-shot\n                           deep trajectory supervision (all K steps supervised directly against\n                           the true field, in-sample)\n  step size             : IRC-FNO's alpha is a least-squares line search per stage (data-driven,\n                           no free hyperparameter); IRNO's alpha is a fixed hyperparameter chosen\n                           up front\n  acceptance            : IRC-FNO validation-gates each stage (rolled back if it doesn't improve\n                           held-out validation MSE) and can stop early; IRNO always runs the full\n                           K steps, with no per-step accept/reject\n  spectral handling     : IRC-FNO selects an exact FNO-representable Fourier mode budget (PSD-\n                           matched) per corrector; IRNO uses a magnitude-spectrum loss term with\n                           a progressively increasing high-frequency weight across steps, but\n                           imposes no explicit mode budget\n  extrapolation         : IRNO is explicitly designed to run MORE than K steps at test time\n                           (paper's headline claim); IRC-FNO's correctors are validation-gated\n                           and stage-specific, so there is no equivalent \"run more steps\" option\n                           -- the two methods trade off differently here, not just in accuracy\n\nSee irc/irno.py's module docstring for what is and is not a faithful reproduction of the paper.\n"


def parse():
    ap = argparse.ArgumentParser(
        description="Compare IRC-FNO and IRNO test results on the same split.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument(
        "--irc-run-dir",
        required=True,
        help="material-model directory containing <component>_seed<seed>/",
    )
    ap.add_argument("--component", required=True)
    ap.add_argument("--irc-seed", type=int, default=0)
    ap.add_argument("--irno-run-dir", required=True)
    ap.add_argument("--out", default=None)
    return ap.parse_args()


def main():
    a = parse()
    irc_path = os.path.join(a.irc_run_dir, f"{a.component}_seed{a.irc_seed}", "test_report.json")
    irno_path = os.path.join(a.irno_run_dir, "test_report.json")
    with open(irc_path) as f:
        irc = json.load(f)
    with open(irno_path) as f:
        irno = json.load(f)
    rows = {
        "base_R2": (irc["test_base"]["R2"], irno["test_base"]["R2"]),
        "final_R2": (irc["test_final"]["R2"], irno["test_final"]["R2"]),
        "base_RMSE": (irc["test_base"]["RMSE"], irno["test_base"]["RMSE"]),
        "final_RMSE": (irc["test_final"]["RMSE"], irno["test_final"]["RMSE"]),
        "params_total": (
            irc["accounting"]["params_total_effective"],
            irno["accounting"]["params_total_effective"],
        ),
        "inference_flops_per_sample": (
            irc["accounting"]["inference_flops_per_sample"],
            irno["accounting"]["inference_flops_per_sample"],
        ),
        "n_forward_passes": (
            irc["accounting"]["n_forward_passes"],
            irno["accounting"]["n_forward_passes"],
        ),
    }
    comparison = dict(
        component=a.component,
        irc_run_dir=a.irc_run_dir,
        irno_run_dir=a.irno_run_dir,
        irc_vs_irno={
            k: dict(irc=v[0], irno=v[1], delta_irno_minus_irc=v[1] - v[0]) for k, v in rows.items()
        },
        irno_extrapolation_R2_by_K=irno.get("extrapolation_R2_by_K", {}),
        architectural_differences=ARCH_DIFFERENCES,
    )
    out = a.out or os.path.join(a.irno_run_dir, "comparison.json")
    with open(out, "w") as f:
        json.dump(comparison, f, indent=2)
    print(
        f"IRC-FNO final test R2 = {irc['test_final']['R2']:.4f}   IRNO final test R2 = {irno['test_final']['R2']:.4f}   (IRNO - IRC = {irno['test_final']['R2'] - irc['test_final']['R2']:+.4f})"
    )
    print(
        f"params: IRC-FNO {irc['accounting']['params_total_effective'] / 1000000.0:.3f}M  vs  IRNO {irno['accounting']['params_total_effective'] / 1000000.0:.3f}M"
    )
    print(ARCH_DIFFERENCES)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
