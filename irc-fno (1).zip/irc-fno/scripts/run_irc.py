import argparse
import json
import os
import sys

import numpy as np
import pandas as pd
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from irc import data as Dm
from irc import physics as Ph
from irc.model import target_width
from irc.pipeline import COMPONENT_OVERRIDES, DEFAULTS, Ctx, run_component


def make_synthetic(N=40, H=32, W=32, seed=0):
    from scipy.ndimage import gaussian_filter

    rng = np.random.default_rng(seed)
    X = np.zeros((N, H, W), np.float32)
    fp = np.zeros((N, H, W, 3, 3), np.float32)
    for i in range(N):
        f = gaussian_filter(rng.standard_normal((H, W)), 2.5, mode="wrap")
        X[i] = (f > np.quantile(f, 0.8)).astype(np.float32)
        soft = 1 - gaussian_filter(X[i], 1.5, mode="wrap")
        band = gaussian_filter(soft * np.roll(soft, 3, (0, 1)), 1.0, mode="wrap")
        g0, g1 = np.gradient(gaussian_filter(X[i], 1.0, mode="wrap"))
        e = 0.02 * band
        fp[i, :, :, 0, 0] = 1 + e
        fp[i, :, :, 1, 1] = 1 / np.sqrt(1 + e)
        fp[i, :, :, 2, 2] = 1 / np.sqrt(1 + e)
        fp[i, :, :, 0, 1] = 0.01 * g0 * band
        fp[i, :, :, 1, 0] = 0.004 * g1 * band
    return (X, fp)


def parse():
    ap = argparse.ArgumentParser(
        description="Train and evaluate the IRC-FNO pipeline (base FNO + iterative residual correctors).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--out", required=True, help="new output directory (must not exist)")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument(
        "--plasticity-root",
        default=None,
        help='path to the "PLASTICITY DATA" folder; enables the structured multi-material-model run (see module docstring)',
    )
    ap.add_argument(
        "--material-models",
        nargs="+",
        default=None,
        help='subfolders of --plasticity-root to run, in order (default: Isotropic, Linear, "Power Law", whichever exist)',
    )
    ap.add_argument(
        "--morphologies",
        nargs="+",
        default=list(Dm.DEFAULT_MORPHOLOGIES),
        help="morphology subfolders to load and concatenate per material model",
    )
    ap.add_argument("--data-path", default=".")
    ap.add_argument("--micro-file", default="texture_combined.npy")
    ap.add_argument("--fp-file", default="fp_combined.npy")
    ap.add_argument("--load-file", default=None)
    ap.add_argument(
        "--desc-cache", default=None, help="descriptor cache dir (default: dataset out dir)"
    )
    ap.add_argument(
        "--morph-file",
        default=None,
        help="(N,) int class labels for stratification (legacy layout only; the real layout derives this automatically)",
    )
    ap.add_argument(
        "--morph-blocks",
        type=int,
        default=None,
        help="assume the file is this many contiguous equal-size classes (legacy layout only)",
    )
    ap.add_argument("--groups-file", default=None, help="(N,) group ids kept in one split")
    ap.add_argument(
        "--split-file",
        default=None,
        help="reuse this split; created if missing (legacy single-dataset layout only -- each material model in --plasticity-root mode gets its own split.json since sample counts differ across models)",
    )
    ap.add_argument("--split-fracs", type=float, nargs=4, default=[0.7, 0.1, 0.1, 0.1])
    ap.add_argument("--split-seed", type=int, default=0)
    ap.add_argument("--components", nargs="+", default=["fp_11", "fp_22", "fp_12"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--mode", choices=("irc", "base"), default="irc")
    ap.add_argument("--config", default=None, help="JSON file of config overrides")
    ap.add_argument(
        "--set",
        nargs="*",
        default=[],
        metavar="KEY=VALUE",
        help="config overrides, e.g. --set crossfit_folds=0 augment=uniaxial_x",
    )
    ap.add_argument("--modes", type=int, nargs=2, default=None)
    ap.add_argument("--width", type=int, default=None)
    ap.add_argument("--layers", type=int, default=None)
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument(
        "--target-params",
        type=float,
        default=None,
        help="choose base width so spectral params ~ this (capacity matching)",
    )
    ap.add_argument("--deterministic", action="store_true")
    ap.add_argument("--cpu", action="store_true")
    return ap.parse_args()


def _coerce(v):
    try:
        return json.loads(v)
    except json.JSONDecodeError:
        return v


def _slug(name):
    return name.replace(" ", "_")


def process_dataset(
    X_raw, fp_all, load, morph_labels, morph_names, out_dir, a, overrides, label, top_logf=None
):
    os.makedirs(out_dir, exist_ok=True)
    logf = open(os.path.join(out_dir, "log.txt"), "a")

    def log(msg=""):
        line = f"[{label}] {msg}" if label else msg
        print(line, flush=True)
        logf.write(line + "\n")
        logf.flush()
        if top_logf is not None:
            top_logf.write(line + "\n")
            top_logf.flush()

    device = torch.device("cuda" if torch.cuda.is_available() and (not a.cpu) else "cpu")
    log(f"device={device}  torch={torch.__version__}")
    if fp_all.ndim != 5 or fp_all.shape[3:] != (3, 3):
        raise SystemExit(f"expected Fp shape (N,H,W,3,3), got {fp_all.shape}")
    X = Dm.normalize_microstructure(X_raw)
    N, H, W, C = X.shape
    if fp_all.shape[:3] != (N, H, W):
        raise SystemExit(f"microstructure {X.shape} and Fp {fp_all.shape} do not match")
    rep = Dm.data_convention_report(fp_all)
    with open(os.path.join(out_dir, "data_report.json"), "w") as f:
        json.dump(rep, f, indent=2)
    log(f"X {X.shape}  Fp {fp_all.shape}\ndata report: " + json.dumps(rep, indent=1))
    strata = None
    if morph_labels is not None:
        strata = np.asarray(morph_labels, dtype=int)
        log(
            "stratifying by morphology (exact, from file layout): "
            + str({n: int((strata == i).sum()) for i, n in enumerate(morph_names)})
        )
    elif a.morph_file:
        strata = np.load(a.morph_file).astype(int)
    elif a.morph_blocks:
        strata = Dm.strata_from_blocks(N, a.morph_blocks)
        log(f"ASSUMPTION: file = {a.morph_blocks} contiguous equal classes (--morph-blocks)")
    groups = np.load(a.groups_file) if a.groups_file else None
    split_path = os.path.join(out_dir, "split.json")
    if a.split_file and label is None and os.path.exists(a.split_file):
        split, meta = Dm.load_split(a.split_file, N)
        log(f"reusing split {a.split_file} (meta {meta})")
    else:
        split = Dm.make_splits(N, a.split_fracs, a.split_seed, groups, strata)
        Dm.save_split(
            split_path,
            split,
            dict(
                N=N,
                fracs=list(a.split_fracs),
                seed=a.split_seed,
                stratified=strata is not None,
                grouped=groups is not None,
                material_model=label,
            ),
        )
        log(f"created split {split_path}")
    log("split sizes: " + str({k: len(v) for k, v in split.items()}))
    if strata is not None:
        log(
            "class counts per split: "
            + str({k: np.bincount(strata[v]).tolist() for k, v in split.items()})
        )
    cfg0 = {**DEFAULTS, **overrides}
    cache = a.desc_cache or out_dir
    D_raw, dt = Dm.get_descriptors(
        X,
        cache,
        cfg0["sigma_curv_list"],
        cfg0["periodic"],
        cfg0["n_states"],
        load,
        cfg0["descriptor_version"],
    )
    scaler = Dm.ChannelScaler().fit(D_raw[split["train"]])
    D = scaler.transform(D_raw)
    del D_raw
    np.savez(os.path.join(out_dir, "descriptor_scaler.npz"), **scaler.state())
    dead = Dm.dead_channels(D, split["train"])
    log(
        f"descriptors {D.shape}, constant (dead) channels on train: {dead}"
        + (f", build time {dt * 1000.0:.1f} ms/sample" if dt else "")
    )
    perms = None
    if cfg0["augment"] != "none":
        perms = Dm.derive_descriptor_perms(
            Dm.AUG_GROUPS[cfg0["augment"]],
            C,
            cfg0["sigma_curv_list"],
            cfg0["periodic"],
            cfg0["n_states"],
            0 if load is None else load.shape[1],
            version=cfg0["descriptor_version"],
        )
        log(
            f"augmentation {cfg0['augment']}: descriptor permutations "
            + str({k: v.tolist() for k, v in perms.items()})
        )
    ctx = Ctx(X, D, fp_all, split, out_dir, device, perms, strata, cfg0["periodic"], log)
    summary = []
    for seed in a.seeds:
        for comp in a.components:
            np.random.seed(seed)
            torch.manual_seed(seed)
            cfg = {**DEFAULTS, **COMPONENT_OVERRIDES.get(comp, {}), **overrides}
            if a.target_params:
                cfg["width"] = target_width(
                    a.target_params, cfg["modes1"], cfg["modes2"], cfg["n_layers"]
                )
                log(f"{comp}: width set to {cfg['width']} for ~{a.target_params:.3g} params")
            row = run_component(comp, Dm.COMPONENTS[comp], ctx, cfg, seed, a.mode)
            row["material_model"] = label
            summary.append(row)
            pd.DataFrame(summary).to_csv(os.path.join(out_dir, "summary.csv"), index=False)
    df = pd.DataFrame(summary)
    log("\n" + df.to_string(index=False))
    if len(a.seeds) > 1:
        agg = df.groupby("component")[
            ["test_R2_base", "test_R2_final", "test_RMSE_final", "params_total_M"]
        ].agg(["mean", "std"])
        agg.to_csv(os.path.join(out_dir, "summary_over_seeds.csv"))
        log("\n" + agg.to_string())
    _write_gnd_reports(out_dir, fp_all, split["test"], a.seeds, log)
    logf.close()
    return summary


def _write_gnd_reports(out_dir, fp_all, test_idx, seeds, log):
    fp21_true = fp_all[test_idx][..., 1, 0].astype(np.float32)
    for seed in seeds:
        comp_fields = {"fp_21": {"true": fp21_true}}
        for comp in Dm.COMPONENTS:
            npz_path = os.path.join(out_dir, f"{comp}_seed{seed}", "arrays", "test_predictions.npz")
            if os.path.exists(npz_path):
                z = np.load(npz_path)
                comp_fields[comp] = {"true": z["y_true"], "pred": z["y_final"]}
        rep = Ph.gnd_report_from_predictions(comp_fields)
        if not rep:
            continue
        path = os.path.join(out_dir, f"gnd_report_seed{seed}.json")
        with open(path, "w") as f:
            json.dump(rep, f, indent=2)
        log(
            f"GND/Nye-tensor consistency (seed {seed}, predicted vs true curl(Fp), NOT forced to zero) -> {path}:\n"
            + json.dumps(rep, indent=1)
        )


def main():
    a = parse()
    if os.path.exists(a.out) and os.listdir(a.out):
        raise SystemExit(f"{a.out} exists and is not empty; choose a new --out")
    os.makedirs(a.out, exist_ok=True)
    top_logf = open(os.path.join(a.out, "log.txt"), "a")

    def top_log(msg=""):
        print(msg, flush=True)
        top_logf.write(msg + "\n")
        top_logf.flush()

    if a.deterministic:
        torch.use_deterministic_algorithms(True, warn_only=True)
        torch.backends.cudnn.benchmark = False
    top_log(f"torch={torch.__version__}  args={vars(a)}")
    overrides = {}
    if a.config:
        with open(a.config) as f:
            overrides.update(json.load(f))
    for kv in a.set:
        k, v = kv.split("=", 1)
        if k not in DEFAULTS:
            raise SystemExit(f"unknown config key {k!r}")
        overrides[k] = _coerce(v)
    if a.modes:
        overrides.update(modes1=a.modes[0], modes2=a.modes[1])
    if a.width:
        overrides["width"] = a.width
    if a.layers:
        overrides["n_layers"] = a.layers
    if a.epochs:
        overrides["epochs"] = a.epochs
    if a.smoke:
        overrides = {
            **dict(
                epochs=3,
                res_epochs=2,
                max_iter=2,
                crossfit_folds=2,
                batch_size=4,
                modes1=6,
                modes2=6,
                width=8,
                n_layers=2,
                res_width=8,
                res_n_layers=2,
                T_0=2,
                log_every=1,
                early_stop_patience=None,
                mc_samples=3,
                tol_r2=-1.0,
                res_r2_floor=-1000000000.0,
            ),
            **overrides,
        }
        a.split_fracs = [0.5, 0.2, 0.15, 0.15]
    all_rows = []
    if a.plasticity_root:
        models = a.material_models or Dm.discover_material_models(a.plasticity_root)
        top_log(f"material models: {models}   morphologies: {a.morphologies}")
        for model in models:
            top_log(f"\n=== material model: {model} ===")
            X_raw, fp_all, morph_labels, morph_names = Dm.load_plasticity_material(
                a.plasticity_root, model, a.morphologies
            )
            top_log(f"{model}: loaded {len(X_raw)} samples across {len(morph_names)} morphologies")
            out_dir = os.path.join(a.out, _slug(model))
            rows = process_dataset(
                X_raw,
                fp_all,
                None,
                morph_labels,
                morph_names,
                out_dir,
                a,
                overrides,
                model,
                top_logf,
            )
            all_rows.extend(rows)
    else:
        if a.smoke:
            X_raw, fp_all = make_synthetic()
            load = None
        else:
            X_raw = np.load(os.path.join(a.data_path, a.micro_file))
            fp_all = np.load(os.path.join(a.data_path, a.fp_file), mmap_mode="r")
            load = np.load(os.path.join(a.data_path, a.load_file)) if a.load_file else None
        rows = process_dataset(X_raw, fp_all, load, None, None, a.out, a, overrides, None, None)
        all_rows.extend(rows)
    df = pd.DataFrame(all_rows)
    all_summary_path = os.path.join(a.out, "summary_all.csv")
    df.to_csv(all_summary_path, index=False)
    top_log(f"\n=== combined summary ({all_summary_path}) ===\n" + df.to_string(index=False))
    if a.plasticity_root and len(a.seeds) > 1:
        agg = df.groupby(["material_model", "component"])[
            ["test_R2_base", "test_R2_final", "test_RMSE_final", "params_total_M"]
        ].agg(["mean", "std"])
        agg.to_csv(os.path.join(a.out, "summary_all_over_seeds.csv"))
        top_log("\n" + agg.to_string())
    top_logf.close()


if __name__ == "__main__":
    main()
