import argparse
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
ABLATIONS = {
    "E3_no_crossfit": ["crossfit_folds=0", 'alpha_policy="val_ls"'],
    "E4_fixed_modes": ['res_mode_policy="fixed"', "res_modes_fixed=[32,26]"],
    "E5_state_input": ["res_state_input=true"],
    "E7_descriptor_v1": ['descriptor_version="v1"'],
    "E8_no_spectral_loss": ["res_lambda_spec=0"],
}
E6_NAME, E6_OVERRIDES = ("E6_augment_uniaxial_x", ['augment="uniaxial_x"'])


def parse():
    ap = argparse.ArgumentParser(
        description="Run the IRC-FNO ablation suite for one material model and component.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--out", required=True, help="parent directory for all ablation runs")
    ap.add_argument("--plasticity-root", default=None)
    ap.add_argument("--material-models", nargs="+", default=None)
    ap.add_argument("--morphologies", nargs="+", default=None)
    ap.add_argument("--data-path", default=None)
    ap.add_argument("--micro-file", default=None)
    ap.add_argument("--fp-file", default=None)
    ap.add_argument("--morph-file", default=None)
    ap.add_argument("--morph-blocks", type=int, default=None)
    ap.add_argument(
        "--components",
        nargs="+",
        required=True,
        help="run one component at a time for a fast, informative ablation sweep (fp_12 is the hardest/most informative, per EXPERIMENTS.md)",
    )
    ap.add_argument("--seeds", type=int, nargs="+", default=[0])
    ap.add_argument("--split-seed", type=int, default=0)
    ap.add_argument("--split-fracs", type=float, nargs=4, default=[0.7, 0.1, 0.1, 0.1])
    ap.add_argument(
        "--include-e6",
        action="store_true",
        help="also run E6 (augmentation) -- only if your loading is mirror-symmetric uniaxial and phases are reflection-invariant",
    )
    ap.add_argument("--skip", nargs="*", default=[], help="ablation names to skip")
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument(
        "--extra-set",
        nargs="*",
        default=[],
        metavar="KEY=VALUE",
        help="extra --set overrides applied to EVERY run (E1 and every ablation), e.g. for a quick CPU check: epochs=5 max_iter=1 crossfit_folds=1",
    )
    return ap.parse_args()


def _common_args(a):
    c = []
    if a.plasticity_root:
        c += ["--plasticity-root", a.plasticity_root]
        if a.material_models:
            c += ["--material-models"] + a.material_models
        if a.morphologies:
            c += ["--morphologies"] + a.morphologies
    else:
        c += ["--data-path", a.data_path or "."]
        if a.micro_file:
            c += ["--micro-file", a.micro_file]
        if a.fp_file:
            c += ["--fp-file", a.fp_file]
        if a.morph_file:
            c += ["--morph-file", a.morph_file]
        if a.morph_blocks:
            c += ["--morph-blocks", str(a.morph_blocks)]
    c += ["--components"] + a.components
    c += ["--seeds"] + [str(s) for s in a.seeds]
    c += ["--split-seed", str(a.split_seed), "--split-fracs"] + [str(x) for x in a.split_fracs]
    if a.cpu:
        c.append("--cpu")
    return c


def main():
    a = parse()
    os.makedirs(a.out, exist_ok=True)
    ablations = dict(ABLATIONS)
    if a.include_e6:
        ablations[E6_NAME] = E6_OVERRIDES
    plan = [("E1_irc", [])] + [(n, ov) for n, ov in ablations.items() if n not in a.skip]
    run_dirs = {}
    for name, overrides in plan:
        run_out = os.path.join(a.out, name)
        if os.path.exists(run_out) and os.listdir(run_out):
            print(
                f"[{name}] {run_out} already exists and is non-empty -- skipping (delete it to re-run)"
            )
            run_dirs[name] = run_out
            continue
        cmd = [sys.executable, os.path.join(ROOT, "run_irc.py"), "--out", run_out]
        cmd += _common_args(a)
        if overrides or a.extra_set:
            cmd += ["--set"] + overrides + list(a.extra_set)
        print(f"\n=== {name} ===\n" + " ".join(cmd))
        r = subprocess.run(cmd)
        if r.returncode != 0:
            print(f"[{name}] FAILED (exit {r.returncode}) -- continuing with the rest")
            continue
        run_dirs[name] = run_out
    if "E1_irc" not in run_dirs:
        raise SystemExit("E1_irc did not complete; cannot build the ablation comparison")
    ablation_dirs = {n: d for n, d in run_dirs.items() if n != "E1_irc"}
    if not ablation_dirs:
        print("no ablations completed; nothing to compare")
        return
    report_out = os.path.join(a.out, "ablation_report")
    os.makedirs(report_out, exist_ok=True)
    cmd = [
        sys.executable,
        os.path.join(ROOT, "analyze_results.py"),
        "--baseline",
        run_dirs["E1_irc"],
        "--out",
        report_out,
        "--ablation",
    ]
    cmd += [f"{n}={d}" for n, d in ablation_dirs.items()]
    print("\n=== comparing ablations to E1 ===\n" + " ".join(cmd))
    subprocess.run(cmd, check=True)
    print(f"\nablation comparison written to {os.path.join(report_out, 'ablation_summary.csv')}")


if __name__ == "__main__":
    main()
